---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Instructions

このディレクトリは、LLM / Agent が外部メモリーを安全かつ一貫して扱うための指示を格納する領域です。

## 目的

- 外部メモリーへの読み取りルールを定義する
- 更新時の責務分離を明確にする
- 定期整理・統合・削除ルールを固定する
- 作業継続時の再開ポイントを明示する

## 代表的な利用例

- 1段階目のカスタム指示
- 週次または定期的な記憶整理プロンプト
- 未記録情報の判定ルール
- 重要な状態変化の抽出指示

## 参照先

- [INDEX.md](./INDEX.md)
- [../docs/ARCHITECTURE.md](../docs/ARCHITECTURE.md)
- [../okf_repository/README.md](../okf_repository/README.md)
