---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Level 1 Custom Instructions

## 基本方針

- 外部メモリーは会話の全文ではなく、継続作業に必要な状態・判断・知識を保持する
- 重要な現在状態は `okf_repository/memory/state/` に保存する
- 重要な変化は `okf_repository/memory/events/` に保存する
- 再利用できる知識は `okf_repository/knowledge/` に整理する
- 特定テーマの事例や実運用記録は `okf_repository/knowledge_at/` に保管する

## Read Rules

- 必要最小限の情報だけを読む
- まず State から現在状況を確認する
- 必要に応じて関連する Event や Knowledge を参照する
- 全体を一括ではなく、対象の範囲だけを読む

## Write Rules

- 既存文書を更新する前に先に現在の内容を確認する
- 新情報が State を更新するなら、State を優先して修正する
- 重大な意思決定や節目は Event に残す
- 共有・再利用可能な知識は Knowledge に抽出する
- 機密情報や認証情報は保存しない

## Consolidation Rules

- 重複した State は統合する
- 独立価値の低い Event は整理する
- 旧版の Knowledge は必要時だけ残す
- 追跡可能な履歴は Git に委ねる
