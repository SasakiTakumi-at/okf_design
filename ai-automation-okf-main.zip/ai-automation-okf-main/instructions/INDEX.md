---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Instructions Index

## 目的

このディレクトリには、AI / Agent が OKF を外部メモリーとして安全に運用するための指示を置く。

## 主な指示

- `README.md` : 役割と方針の概要
- `memory-consolidation-prompt.md` : 定期整理のプロンプト
- `level-1-custom-instructions.md` : 初期レベルのカスタムルール

## 運用ルール

- 事実に基づく記録を行う
- 現在状態と再利用知識を分離する
- 重要でない雑談や生の会話全文を保存しない
- 重要な変化は `memory/events/` に残す
- 一般化可能な知識は `knowledge/` に整理する
