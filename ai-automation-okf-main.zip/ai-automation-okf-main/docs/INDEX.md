---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Documentation Index

このリポジトリの詳細資料は、役割ごとに整理し、OpenWebUI を使ったシナリオ作成と検証蓄積の運用に対応させています。

## 参照順

1. [README.md](./README.md) — 利用目的と全体像
2. [ARCHITECTURE.md](./ARCHITECTURE.md) — 保存領域と責務分離
3. [DEVELOPMENT_GUIDE.md](./DEVELOPMENT_GUIDE.md) — 実運用フローとシナリオ作成ルール
4. [NAME_RULE.md](./NAME_RULE.md) — 命名規約
5. [GLOSSARY.md](./GLOSSARY.md) — 用語定義
6. [SPEC.md](./SPEC.md) — OKF の設計上の制約と粒度
7. [AGENTS.md](./AGENTS.md) — LLM / Agent 向けの運用指示

## 各ドキュメントの役割

### README.md

このリポジトリの目的、利用用途、記録対象の区分を説明します。

### ARCHITECTURE.md

Memory / Knowledge / knowledge_at / device_docs / template の責務と、シナリオ実行結果・インシデント・切り分けテストの保存設計を説明します。

### DEVELOPMENT_GUIDE.md

OpenWebUI での作成フロー、検証の記録ルール、成功/失敗/インシデントの区分、再利用知識への抽出方法を説明します。合わせて、Metadata の記載方法と関連付けの運用を定義します。

### NAME_RULE.md

命名に関するルールを定義し、Robot keyword、補助関数、Robot ファイル名、PythonLibrary ファイル名、記録ファイル名の命名を統一します。Robot や記録ファイルの先頭番号は必須にせず、関連記録のメタデータ形式も含めて整理します。

### GLOSSARY.md

Scenario、Incident、Triage Test、Keyword などの用語を統一します。

### SPEC.md

OKF の保存粒度、記録単位、情報管理の設計制約を定義します。

### AGENTS.md

LLM / Agent が外部メモリーを安全かつ一貫して扱うための指示を定義します。

## このリポジトリで扱う主な運用

- Scenario の作成と保存
- 検証の実行と成功記録
- インシデントの記録
- 切り分けテストの追跡
- 再利用可能な知識への抽出
- Git 履歴による変化追跡