---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Architecture

## 全体像

OKF を使った外部メモリーは、記憶の保存と知識の再利用を分離して管理することが重要です。

今回の構成では、OKF はワークスペース内の一要素として扱い、実行・生成・編集の一時作業領域と正式な記録領域を分離します。

なお、本文中で説明する `ai-automation-platform/`、`ai-automation_test_docs/`、`ai-automation_pf_harness/` は、この `ai-automation-okf` リポジトリの内部配置ではなく、同じワークスペースに並立する関連プロジェクトや作業領域を指します。OKF リポジトリ本体自体は `docs/`、`generator/`、`instructions/`、`okf_repository/` を管理します。

### 4 リポジトリの全体構成

```text
.
├── ai-automation-platform/         # 実行基盤・自動化実装領域
│   ├── src/                       # 実行基盤とソースコードの中心
│   │   ├── core/                  # 共通基盤（ansible / network / event / models / robot）
│   │   │   └── robot/
│   │   │       └── libs/
│   │   ├── main/                  # 実行入口と制御
│   │   └── user/                  # 実装・生成・プロジェクトの作業領域
│   │       ├── generated/          # Robot/Python 原本とレポートの作業領域
│   │       │   ├── projects/
│   │       │   ├── libraries/
│   │       │   └── reports/
│   │       ├── projects/
│   │       ├── platforms/
│   │       ├── libraries/
│   │       └── user_platforms.py
│   └── README.md
│
├── ai-automation_test_docs/        # ユーザー操作・手順書・計画書の作業領域
│   ├── profiles/
│   ├── test_plan/
│   ├── test_procedure/
│   └── README.md
│
├── ai-automation-okf/              # OKF の保存・再利用・知識管理領域
│   ├── README.md
│   ├── docs/
│   │   ├── README.md
│   │   ├── INDEX.md
│   │   ├── AGENTS.md
│   │   ├── ARCHITECTURE.md
│   │   ├── DEVELOPMENT_GUIDE.md
│   │   ├── GLOSSARY.md
│   │   ├── NAME_RULE.md
│   │   └── SPEC.md
│   ├── generator/
│   │   ├── generate_code.py
│   │   └── prompts.py
│   ├── instructions/
│   │   ├── README.md
│   │   ├── level-1-custom-instructions.md
│   │   └── memory-consolidation-prompt.md
│   ├── okf_repository/
│   │   ├── README.md
│   │   ├── memory/
│   │   │   ├── README.md
│   │   │   ├── events/
│   │   │   └── state/
│   │   ├── knowledge_at/
│   │   │   ├── INDEX.md
│   │   │   ├── incidents/
│   │   │   ├── robot/
│   │   │   ├── python/
│   │   │   └── testcases/
│   │   ├── knowledge/
│   │   │   ├── INDEX.md
│   │   │   ├── workflows/
│   │   │   ├── references/
│   │   │   ├── decisions/
│   │   │   └── experiments/
│   │   ├── device_docs/
│   │   └── template/
│   └── .git/
│
├── ai-automation_pf_harness/       # 実行支援ハーネス領域
│   ├── main.py
│   ├── general.yml
│   ├── .secret.yml
│   ├── agents/
│   │   ├── agent_builder.py
│   │   ├── router/
│   │   ├── normal_chat/
│   │   ├── info/
│   │   ├── test_plan_path_finder/
│   │   ├── test_plan_gate/
│   │   └── test_plan_builder/
│   ├── tools/
│   │   ├── tool_registry.py
│   │   ├── mcpo_tool_loader.py
│   │   └── local/
│   ├── utils/
│   │   ├── settings_loader.py
│   │   ├── git_repository.py
│   │   ├── checkpoint_cleanup.py
│   │   ├── open_webui_client.py
│   │   └── logger.py
│   ├── workflow/
│   │   ├── graph.py
│   │   ├── nodes.py
│   │   ├── edges.py
│   │   ├── state.py
│   │   ├── context.py
│   │   ├── schemas/
│   │   ├── info_workflow/
│   │   └── test_workflow/
│   └── README.md
│
└── ai_automation_repos.md          # ワークスペース構成の補助資料
```

- `ai-automation-platform/` : 実装と検証の実体
- `ai-automation_test_docs/` : 手順書・実行計画・草案の原本
- `ai-automation-okf/` : knowledge / memory / knowledge_at の正式保存先
- `ai-automation_pf_harness/` : 実行支援と業務フロー制御の補助基盤

構成の中心は次の 5 つの領域です。

- Memory
- device_docs
- knowledge
- knowledge_at
- template

## ai-automation-platform の責務整理

ai-automation-platform は、OKF と対になる「生成・実行・検証の実体」です。ここでは、次の責務を分離して管理します。

- src/core/: 実行基盤と共通処理の集合
  - ansible, network, event, models などの共通機能
  - robot/ は Robot 実行の基盤とライブラリの中心
- src/main/: 起動と制御の入口
- src/user/generated/: 生成中の原本保存場所
  - projects/, libraries/, reports/
- src/user/projects/: 実運用の対象プロジェクトや試験シナリオの保管先
- src/user/platforms/ と src/user/libraries/: 実装差分の抽象化や再利用可能な環境別コード

この設計では、OKF は「履歴と再利用知識」を担当し、ai-automation-platform は「現実の自動化実装と検証結果の実体」を担当するという役割分担を前提にしています。そのため、シナリオ生成時に必要な情報は、原本の置き場と正式記録の置き場を区別して扱うのが基本です。

また、作業の生成元として ai-automation_test_docs/ と ai-automation-platform/src/user/generated/ を使い、正式保存先として ai-automation-okf/okf_repository/knowledge_at/ を使います。ここで重要なのは、手順書と実行計画書の原本は ai-automation_test_docs/test_procedure/ と ai-automation_test_docs/test_plan/ に残し、Robot / Python の原本は ai-automation-platform/src/user/projects/ と ai-automation-platform/src/user/libraries/ に残すという設計です。実装と同時に生成されるレポートは ai-automation-platform/src/user/generated/reports/ に一時保存し、再利用に値する情報だけを knowledge_at の記録フォーマットに沿って書き出します。

## 責務分離

### Memory

Memory は現在の状態を保持するための領域です。

- 現在の作業状態
- 実行中のコンテキスト
- 最重要な判断結果
- 現在の Source of Truth

Memory は「再利用のための知識」ではなく、「その時点での正確な作業状態」を管理します。

### device_docs

device_docs は設備・技術・運用ドキュメントの参照資産です。

- 機器の設定例
- コマンドリファレンス
- 仕様・制約条件
- 参照すべき既存資料

これらは知識としての価値が高い一方、現在の作業状態とは分離して管理します。

### knowledge

knowledge は、再利用可能な原則や手順に関する知識です。

- 概念
- ワークフロー
- ツール利用方法
- 参考資料
- 実験知見
- 判断結果

knowledge は繰り返し活用可能な情報を持ちます。

### knowledge_at

knowledge_at は、特定の文脈やシナリオ、事象、ケースに紐づく知識を蓄積する領域です。

一時作業領域の ai-automation_test_docs/ で作成した実行計画書や設計判断レポートは、作業完了時にここへ格納・反映します。Robot や Python の生成物は、元の原本として ai-automation-platform/src/user/projects/ と ai-automation-platform/src/user/libraries/ に作成し、実装に伴うレポートは ai-automation-platform/src/user/generated/reports/ に一時保存します。再利用に値するものだけを `ai-automation-okf/okf_repository/knowledge_at/` に反映します。ai-automation_test_docs/ は手順書や実行計画の作業原本の保管場所であり、正式保存先とは分離します。

- シナリオ
- テストケース
- インシデント事例
- 実運用に即した記録
- 社内独自の検証知見
- 特定環境に依存する判断理由

### template

template は反復利用される書式や雛形です。

- テストケースの雛形
- インシデント記録テンプレート
- Python 実装テンプレート
- Robot Framework テンプレート

## シナリオ駆動検証の保存設計

今回の利用用途では、単に「知識を保管する」だけではなく、検証シナリオを作成し、実行し、その結果を蓄積する運用が中心になります。

### 1. Scenario 作成

OpenWebUI で作成するシナリオは、対象環境や機器仕様に紐づく実行計画として扱います。

- 目的
- 前提条件
- 対象機器
- 実行コマンド
- 期待結果
- 異常時の想定

この種の情報は、通常 ai-automation_test_docs/ で草案を作成し、Robot / Python の原本は ai-automation-platform/src/user/projects/ と ai-automation-platform/src/user/libraries/ で作成したあと、レポートは ai-automation-platform/src/user/generated/reports/ に出力し、完成したシナリオを `knowledge_at/robot/`、ライブラリ実装は `knowledge_at/python/` へ反映します。

### 2. 実行結果の保存

検証を実行した結果は、成功と失敗を区別して記録します。

- 成功結果: `knowledge_at/testcases/` は、実行後に確認できた成功・正常系の証跡として残す正式な記録領域。未実行の仮説や生成フェーズの草案はここに置かない
- Robot シナリオ: `knowledge_at/robot/` は、実行済み・再利用可能なシナリオ記録を格納する
- Python ライブラリ: `knowledge_at/python/` は、実行済みのライブラリや Keyword 実装の正式記録を格納する
- インシデント: `knowledge_at/incidents/`
- 切り分けテスト: `knowledge_at/testcases/`
- 現在の作業状態: `memory/state/`
- 重要な変化: `memory/events/`

> `testcases/` は、生成器が自動で作る一時ファイルではなく、実測・検証・確認済みの事実を正式に残す保存先です。生成時の草案や未検証の推測は、ここではなく generated 領域やメモリに留めます。

### 3. knowledge と knowledge_at の関係

- knowledge: 汎用的な手順、判断基準、共通ルール
- knowledge_at: 特定シナリオ、特定機器、特定事例、インシデント、切り分けテストの記録

knowledge_at は、特定の文脈に依存した社内実務知識を蓄積する専用領域として位置づけます。

### 4. 成功と失敗の運用ルール

- 成功した検証は、再利用可能なパターンとして knowledge_at に残す
- 失敗や異常は、インシデントとして記録し、再現条件と原因を明確にする
- 切り分けテストは、仮説検証の記録として別件として管理する
- いったん終了した検証でも、再利用価値があるものは knowledge へ抽出する

## Read / Write の基本ルール

### Read

必要な情報だけを最小限の粒度で取得します。

- 現在の State を確認する
- 必要な device_docs を参照する
- knowledge と knowledge_at から関係する情報を選ぶ
- テンプレートを利用する

### Write

保存すべき情報は次の基準で判断します。

- 現在の作業継続に必要か
- 再利用可能か
- 重要な状態遷移か
- 参照されるべき情報か

重要ではない個人のメモや、作業に直接関係ない情報は保存しません。

## 履歴管理

重要な変化は Memory Event として残し、細かな修正は Git 履歴で管理します。

この設計により、重要な変化を残しつつ、現状の Source of Truth を簡潔に保ちます。

## 設計上の利点

- 作業状態と知識を分離できる
- 参照対象を絞って効率化できる
- Git で履歴管理しやすい
- 再利用可能な知識を蓄積しやすい
- 不要な重複を整理しやすい
