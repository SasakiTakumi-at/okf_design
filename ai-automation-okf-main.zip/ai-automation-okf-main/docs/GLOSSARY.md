---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Glossary

## OKF

Open Knowledge Format の略称。

外部メモリーに保存される情報を、再利用しやすい構造で整理するための形式や運用思想を指します。

## Memory

現在の作業状態や重要な状態変化を保持するための領域です。

## Memory State

現在の Source of Truth として扱う状態です。

## Memory Event

重要な状態遷移や価値のある変化を記録したものです。

## Knowledge

再利用可能な知識や手順、概念、判断結果などを蓄積する領域です。

## Knowledge_at

特定のシナリオ、事例、運用条件、検証ケースに紐づく知識を保持する領域です。

特に NTT-AT が独自に保有・再利用したい社内専用の知識として扱うことを想定しています。一般化された Knowledge とは異なり、文脈依存の実務知識や社内特有の事例を蓄積します。

## Robot Framework

テスト自動化で広く使われる Python ベースのテストフレームワークです。

Robot 形式のテストケースとキーワード定義を用いて、CLI やネットワーク機器の検証を記述します。

## Keyword

Robot Framework で利用される実行単位です。

`@keyword('名前')` を使って Robot 上で参照可能な名を定義し、処理の再利用やテストケースの可読性を高めます。

## Suite Setup / Suite Teardown

テストスイートの開始時と終了時に自動的に実行される共通処理です。

初期化や後処理をまとめて定義し、各テストケースの前後処理を統一できます。

## snake_case

単語をアンダースコアで区切る命名スタイルです。

Robot Framework のファイル名や補助関数名では、小文字の `snake_case` を採用し、可読性と一貫性を維持します。

## Private Helper

Robot Framework で直接呼び出されない補助関数です。

先頭を `_` にすることで、keyword として公開される関数と内部処理用の関数を区別します。例: `_get_value()`

## Device Docs

機器や技術の参照ドキュメントを格納する領域です。

## Template

繰り返し使う記録書式や雛形を保持する領域です。

## Source of Truth

現在の正しい状態を表す主情報源です。

## Git 履歴

過去の変更を追跡し、現在の状態と比較できる記録です。
