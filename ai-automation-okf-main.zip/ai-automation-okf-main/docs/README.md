---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# OKF 設計の背景と全体像

この資料は、OKF を「単体のメモリー保存リポジトリ」ではなく、ワークスペース全体の構成要素として扱う際の設計意図と運用方針をまとめたものです。

なお、本文中で示す `ai-automation-platform/`、`ai-automation_test_docs/`、`ai-automation_pf_harness/` は、この `ai-automation-okf` リポジトリの内部ではなく、同じワークスペース上で並立する関連リポジトリまたは作業領域を指します。実際のこのリポジトリ本体は `docs/`、`generator/`、`instructions/`、`okf_repository/` などで構成されています。

## ワークスペース全体の 4 リポジトリ構成

```text
.
├── ai-automation-platform/         # 実行基盤・自動化実装領域
│   ├── src/                       # 実行基盤とソースコードの中心
│   │   ├── core/                  # 共通基盤（ansible / network / event / models / robot）
│   │   │   └── robot/
│   │   │       └── libs/
│   │   ├── main/                  # 実行入口と制御
│   │   └── user/                  # 実装・生成・プロジェクトの作業領域
│   │       ├── generated/          # Robot/Python 原本とレポートの作業領域
│   │       │   ├── projects/
│   │       │   ├── libraries/
│   │       │   └── reports/
│   │       ├── projects/
│   │       ├── platforms/
│   │       ├── libraries/
│   │       └── user_platforms.py
│   └── README.md
│
├── ai-automation_test_docs/        # ユーザー操作・手順書・計画書の作業領域
│   ├── profiles/
│   ├── test_plan/
│   ├── test_procedure/
│   └── README.md
│
├── ai-automation-okf/              # OKF の保存・再利用・知識管理領域
│   ├── README.md
│   ├── docs/
│   │   ├── README.md
│   │   ├── INDEX.md
│   │   ├── AGENTS.md
│   │   ├── ARCHITECTURE.md
│   │   ├── DEVELOPMENT_GUIDE.md
│   │   ├── GLOSSARY.md
│   │   ├── NAME_RULE.md
│   │   └── SPEC.md
│   ├── generator/
│   │   ├── generate_code.py
│   │   └── prompts.py
│   ├── instructions/
│   │   ├── README.md
│   │   ├── level-1-custom-instructions.md
│   │   └── memory-consolidation-prompt.md
│   ├── okf_repository/
│   │   ├── README.md
│   │   ├── memory/
│   │   │   ├── README.md
│   │   │   ├── events/
│   │   │   └── state/
│   │   ├── knowledge_at/
│   │   │   ├── INDEX.md
│   │   │   ├── incidents/
│   │   │   ├── robot/
│   │   │   ├── python/
│   │   │   └── testcases/
│   │   ├── knowledge/
│   │   │   ├── INDEX.md
│   │   │   ├── workflows/
│   │   │   ├── references/
│   │   │   ├── decisions/
│   │   │   └── experiments/
│   │   ├── device_docs/
│   │   └── template/
│   └── .git/
│
├── ai-automation_pf_harness/       # 実行支援ハーネス領域
│   ├── main.py
│   ├── general.yml
│   ├── .secret.yml
│   ├── agents/
│   │   ├── agent_builder.py
│   │   ├── router/
│   │   ├── normal_chat/
│   │   ├── info/
│   │   ├── test_plan_path_finder/
│   │   ├── test_plan_gate/
│   │   └── test_plan_builder/
│   ├── tools/
│   │   ├── tool_registry.py
│   │   ├── mcpo_tool_loader.py
│   │   └── local/
│   ├── utils/
│   │   ├── settings_loader.py
│   │   ├── git_repository.py
│   │   ├── checkpoint_cleanup.py
│   │   ├── open_webui_client.py
│   │   └── logger.py
│   ├── workflow/
│   │   ├── graph.py
│   │   ├── nodes.py
│   │   ├── edges.py
│   │   ├── state.py
│   │   ├── context.py
│   │   ├── schemas/
│   │   ├── info_workflow/
│   │   └── test_workflow/
│   └── README.md
│
└── ai_automation_repos.md          # ワークスペース全体の構成メモ（補助資料）
```

この 4 つのリポジトリは、生成・実行・記録・支援の責務を分担する前提です。

- 実装中心: `ai-automation-platform/`
- 仕様・手順・草案中心: `ai-automation_test_docs/`
- 知識・記録の正式保存: `ai-automation-okf/`
- 実行支援: `ai-automation_pf_harness/`

## 背景

LLM を長期間利用すると、同じテーマが複数の会話やツールにまたがり、現在状態・決定事項・数値・構成・次回開始点などを再説明する必要が生じます。

この運用では、会話全文そのものを記憶として保存するのではなく、次回に正確に作業を再開するために必要な現在状態を外部へ保存します。

さらに、そこから得られた再利用可能な原則・手順・検証知識は、現在状態とは分離して knowledge として保存します。

## ai-automation-platform の実態と利用方針

ai-automation-platform は、OKF の外部メモリーと連携する実装基盤です。ここでは、実行対象の自動化ロジック、Robot シナリオ、Python 実装、検証レポート、プロジェクト固有設定を保管し、OKF へ再利用可能な知識だけを抽出します。

実際の構成は以下のとおりです。

- src/core/: 実行基盤の共通コード群
  - ansible/, network/, event/, models/, robot/ など
- src/main/: 実行のエントリポイントと起動フロー
- src/user/generated/: 作業中の生成領域
  - projects/, libraries/, reports/
- src/user/projects/: 実プロジェクトや対象シナリオの配置先
- src/user/platforms/ と src/user/libraries/: プラットフォーム抽象化と再利用ライブラリ

シナリオ生成や自動化実装では、以下の順序を守ります。

1. 草案を src/user/generated/ に置く
2. 実行・検証で得た結果を generated/reports/ に残す
3. 再利用価値があるものだけを knowledge_at/ に反映する
4. 実運用の共通知識は knowledge/ に整理する
5. 環境依存の値は設定化し、固有値をハードコードしない

この整理により、生成器やエージェントは「作業原本」「実行用コード」「正式記録」の差異を常に意識しながら作業できます。

## 基本構造

OKF は、単独で完結するリポジトリではなく、ワークスペース内の複数リポジトリと連携して使う構成です。

ここで示す `ai-automation-platform/` や `ai-automation_test_docs/` は、`ai-automation-okf` リポジトリの内部ではなく、同じワークスペースで並立する関連プロジェクトを表す例です。実際の OKF リポジトリ本体は、以下の構成になります。

```text
.
├── README.md
├── docs/
├── generator/
├── instructions/
├── okf_repository/
├── .git/
└── ...
```

ワークスペース内の関連構成は次のような関係です。

```text
.
├── ai-automation-platform/        # 実行基盤と自動化処理
├── ai-automation_test_docs/        # 手順書・計画・草案の作業領域
├── ai-automation-okf/              # OKF の保存・再利用領域
├── ai-automation_pf_harness/       # 実行支援ハーネス
└── ...
```

この中で、ai-automation-okf は実運用の外部メモリーと知識保存を担当し、ai-automation_test_docs は一時的な生成・編集領域として扱います。関連リポジトリの実体や配置はワークスペースごとに変動するため、リポジトリ本体とワークスペース全体の説明を混在させないようにします。

## 記録の生成タイミングと保存先

OKF の設計では、保存先と生成タイミングを分離します。

- Robot / Python の原本は、作業中の生成領域である ai-automation-platform/src/user/projects/ と ai-automation-platform/src/user/libraries/ に作成する
- 実装時に作る一時レポートは ai-automation-platform/src/user/generated/reports/ に残す
- `knowledge_at/robot/` と `knowledge_at/python/` は、実行・検証済みの正式な記録として残す領域である
- `knowledge_at/testcases/` は、実行後に確認できた成功や切り分け結果を正式に蓄積する場所であり、生成フェーズの草案や未実行の仮説では作成しない

つまり、`testcases/` は「自動生成される一時ファイル」ではなく、「実行後の検証結果を正式に保持する記録領域」です。作業中の草案や未確認の仮説は、生成領域やメモリに留め、確認できた事実だけを knowledge_at に反映します。

## 役割分離

Memory では次の区別を行います。

- Memory State = 現在の Source of Truth
- Memory Event = 独立して残す価値がある重要な状態遷移

つまり、現在の作業状態と、履歴として残すべき重要な変化を分けて扱います。

## 設計の意図

この構成では、OKF だけで「記憶機能」が成立すると考えているわけではありません。

OKF は、外部メモリーの保存・分類・参照単位として利用し、次の仕組みと組み合わせて運用します。

- State / Event / Knowledge / knowledge_at / device_docs / template の責務分離
- 参照先と保存先を明確に分ける
- Read / Write フローを固定する
- Git による履歴・差分管理
- 生成物は一時編集領域で整理し、正式保存先へ反映する
- 秘密情報や不要情報を保存しないルール

Git 履歴から過去状態を確認できるため、現行ファイルへ変更履歴を無制限に蓄積しません。

現在の作業継続・判断・再利用に不要になった重複情報は整理し、現在の Source of Truth を正確に保つことを優先します。

## スコープ

この資料で扱うもの:

- OKF を利用した外部メモリー構成
- Memory / Knowledge / knowledge_at / device_docs / template の責務分離
- Read / Write のデータフロー
- Git を利用した履歴管理
- 保存・統合・整理の運用ルール
- LLM / Agent への指示
- ワークスペース全体内での OKF の役割

扱わないもの:

- OKF 仕様そのものの詳細解説
- そのままシステムへ導入できる完成済み実装

## 利用サイクル

必要な情報だけを参照し、作業によって生じた変化を memory・device_docs・knowledge・knowledge_at・template へ反映します。

```mermaid
flowchart LR
    A[開始] --> B[必要情報を選択]
    B --> C[State / Device_docs / Knowledge / Knowledge_at / Template参照]
    C --> D[回答・作業]
    D --> E{新しい情報?}

    E -- いいえ --> Z[次回再開]
    E -- はい --> F{継続に必要?}

    F -- はい --> G[Memory更新]
    F -- いいえ --> H{再利用可能?}

    G --> H
    H -- はい --> I{device_docs統合?}
    H -- いいえ --> J[保存しない]

    I -- はい --> K[device_docs統合]
    I -- いいえ --> L[device_docs統合しない]

    K --> M{knowledge統合?}
    L --> M

    M -- はい --> N[knowledge統合]
    M -- いいえ --> O[knowledge統合しない]

    N --> P{knowledge_at統合?}
    O --> P

    P -- はい --> Q[knowledge_at統合]
    P -- いいえ --> R[knowledge_at統合しない]

    Q --> S[template統合?]
    R --> S

    S -- はい --> T[template統合]
    S -- いいえ --> U[template統合しない]

    G --> V[Git記録]
    T --> V
    U --> V
    J --> Z
    V --> Z
```

## このドキュメントの役割

この README は、OKF の全体像・責務分離・保存判断の基準を説明するための入口である。

- README は「なぜこの構造になっているか」を説明する
- 実務の詳細手順は [DEVELOPMENT_GUIDE.md](DEVELOPMENT_GUIDE.md) と各テンプレートを参照する
- LLM / Agent が扱う場合、この README を基準にして保存先・参照元・更新方針を判断する

## 対象利用者

本リポジトリは、主に LLM / Agent を使った作業での外部メモリー運用を想定している。

- 事実の保存と再利用のために構造化する
- 作業前後で State を正しく扱う
- 再利用可能な知識と個別事例を分離する
- 参照元を残して、情報の出所と信頼性を追跡できるようにする

## 保存対象の判断基準

以下の情報は保存対象とする。

- 現在の作業継続に必要な情報
- 次回再開時に再説明が必要な情報
- 再利用可能な知識
- 重要な状態遷移
- 判定や切り分けの根拠となる値・ログ・出力

以下の情報は原則として保存しないか、後で整理する。

- 一時的な試行錯誤
- 直接の作業に関係ない雑談やメモ
- 重複した内容のコピー
- 確定していない仮説
- 機密や扱いに注意が必要な情報

## 参照元の定義

記録を作成するときは、参照元を分けて残す。

- 参照元（外部/OKF外）: ワークスペース外や外部ドキュメント、URL、公開資料、ログ、計測結果、手順書、別プロジェクトの記録など
- 参照元（OKF 内）: README、docs、template、knowledge、knowledge_at、device_docs、memory、既存の記録など、この OKF 内のファイル

OKF 内の既存ファイルも、作成時に根拠にした場合は必ず参照元に含める。

## 最低限の記載ルール

すべての記録ファイルには、少なくとも次の項目を含める。

- 対象機能
- 実施日
- 実施者
- 検証目的または対象
- 判定
- 根拠
- 参照元
- 関連情報

この最低限の構造を満たさない記録は、参照元不足や判断根拠不足として扱う。

## 使い方の流れ

1. README で全体像と責務分離を把握する
2. DEVELOPMENT_GUIDE で運用ルールを確認する
3. template を使って記録を作成する
4. 必要に応じて knowledge / knowledge_at / device_docs / memory に整理する
5. 参照元と根拠を残して、再利用可能な状態にする

## 位置づけ

この資料は、OKF の仕様紹介そのものではなく、

> 外部メモリーという仕組みの中で、OKF をどのように利用・運用するか

を示すためのものです。

プロジェクト・システム・環境などの State 管理に応用する際の参考資料として利用できます。
