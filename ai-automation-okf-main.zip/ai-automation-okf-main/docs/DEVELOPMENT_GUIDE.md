---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Development Guide

## 利用サイクル

本文中で触れる `ai-automation_test_docs/` や `ai-automation-platform/` は、この OKF リポジトリの内部に含まれるディレクトリではなく、ワークスペースで並立する関連領域を指します。OKF 本体の実体は `docs/`、`generator/`、`instructions/`、`okf_repository/` で構成されます。

### ワークスペース全体の 4 リポジトリ

```text
.
├── ai-automation-platform/         # 実行基盤・自動化実装領域
│   ├── src/
│   │   ├── core/
│   │   │   └── robot/
│   │   ├── main/
│   │   └── user/
│   │       ├── generated/
│   │       │   ├── projects/
│   │       │   ├── libraries/
│   │       │   └── reports/
│   │       ├── projects/
│   │       ├── libraries/
│   │       └── platforms/
│   └── README.md
│
├── ai-automation_test_docs/        # 手順書・計画・草案の作業領域
│   ├── profiles/
│   ├── test_plan/
│   ├── test_procedure/
│   └── README.md
│
├── ai-automation-okf/              # OKF の保存・再利用・知識管理領域
│   ├── README.md
│   ├── docs/
│   ├── generator/
│   ├── instructions/
│   └── okf_repository/
│
├── ai-automation_pf_harness/       # 実行支援ハーネス領域
│   ├── main.py
│   ├── general.yml
│   ├── agents/
│   ├── tools/
│   ├── utils/
│   ├── workflow/
│   └── README.md
│
└── ai_automation_repos.md          # 全体像メモ（補助資料）
```

OKF を使う際の基本サイクルは次の通りです。

1. 必要な情報を選択して参照する
2. 現在状態を確認する
3. 作業を実行する
4. 新しい知見や変更を確認する
5. 保存すべきものを選定する
6. memory / knowledge / device_docs / template / knowledge_at へ反映する
7. Git で履歴を管理する

## 保存の判断基準

以下のような情報は保存対象として扱います。

- 現在の作業継続に必要な情報
- 次回再開時に再説明が必要な情報
- 再利用可能な知識
- 重要な状態遷移
- 参照してほしい技術ドキュメント

以下のような情報は保存しないか、後で整理します。

- 直接の作業に関係ない雑談やメモ
- 実装中に発生した一時的な試行錯誤
- すぐに不要になる情報
- 重複した内容のコピー
- 機密や扱いに注意が必要な情報

## Read / Write フロー

### Read

- まず Memory State を確認する
- 必要に応じて device_docs を確認する
- 既存の knowledge や knowledge_at を参照する
- テンプレートがあれば利用する

### Write

- 新情報を確認したら保存先を選ぶ
- 実行・生成の草案は ai-automation_test_docs/ で整理・編集する
- ユーザーが作成した手順書は、原本として ai-automation_test_docs/test_procedure/ に残す
- ユーザーまたは LLM / Agent が作成した実行計画書は、原本として ai-automation_test_docs/test_plan/ に残す
- Robot などの生成物は、原本として ai-automation-platform/src/user/projects/ に作成・編集する
- Python 実装も原本として ai-automation-platform/src/user/libraries/ に作成・編集する
- 実装と同時に、設計判断・検証結果・要点整理を ai-automation-platform/src/user/generated/reports/ にレポートとして出力する
- 作業完了時に、再利用可能な成果物は okf_repository/knowledge_at/robot/、knowledge_at/python/、または適切な knowledge_at 配下へ記録フォーマットに沿って書き出す
- 原本そのものを正式保存先へそのままコピー・移動するのではなく、必要な情報を正式記録として抽出して保存する
- 実行計画書も手順書と同様に、原本は一時作業領域に残し、再利用に必要な要件・目的・前提・判定観点だけを正式記録として残す
- 実装に伴うレポートは generated/reports に一時保存し、再利用価値が高いものだけを knowledge_at 配下へ整理する
- `knowledge_at/testcases/` は、実行済み・確認済みの検証結果を残す正式領域であり、生成フェーズの仮説や未実施の試験結果はここに置かない
- 現在状態は memory に集約する
- 再利用可能な知識は knowledge に整理する
- 事例やシナリオは knowledge_at に配置する
- 繰り返し使う元データは template に保持する

## ai-automation-platform 利用時の実務ルール

ai-automation-platform は、OKF に対して「実体を持つ生成・実行基盤」を提供する役割があります。シナリオ生成や自動化実装の実務では、次のルールを明確に守ります。

- 元の実装原本は ai-automation-platform/src/user/projects/ と ai-automation-platform/src/user/libraries/ に置く
- 実装に伴う検証や判断のメモは ai-automation-platform/src/user/generated/reports/ に保存する
- 実プロジェクトや環境依存の実体は src/user/projects/、src/user/platforms/、src/user/libraries/ に分離する
- `src/core/` は共通基盤とライブラリ実装の本体として扱い、ノイズの混入を避ける
- 実行・評価後に再利用価値があるものだけを okf_repository/knowledge_at/ に反映する
- 実現場の固有値は、固定値埋め込みではなくパラメータや設定値に変換する

このルールにより、生成器は主に「作業原本」「一時レポート」「正式記録」を切り分けて扱えるようになります。

## Metadata の運用

Knowledge と knowledge_at の情報には、関連付けのためのメタデータを付与します。

```markdown
## Metadata
- Tags: interface, link_down, triage
- Related Keywords: show_interface_status, interface_status, check_link_state
```

- Tags は小文字の snake_case に統一する
- Related Keywords は検索しやすい語を並べる
- 対象機能や関連概念は複数項目として記載できる
- 例: `対象機能: インターフェース, 物理リンク, ポート`

## 検証記録テンプレートの規約

`type: validation` は、その記録が「実施したテスト結果をまとめたものである」ことを示すための識別子とする。

- `対象機能`: 試験対象の機能を検索しやすいように、関連キーワードとして複数項目をカンマ区切りで記載する
  - 例: `対象機能: インターフェース, リンク状態, ポート`
- `試験名`: 実施した試験の正式な名称を記載する
- `実施日`: 実施した日時を記載する
- `実施者`: 実行者の氏名を記載する。未記録の場合は `不明` とする

記録は、対象のテスト手順書・テスト結果・対象環境・前例（存在する場合）を確認したうえで、事実ベースの内容のみを残す。

- 推測や未確認の解釈は記載しない
- 判定の根拠があれば明示する
- 既存の参考情報がある場合は、再利用可能な前例として整理する
- 実測値と観測結果を優先し、想定や憶測を混ぜない
- 検証結果は簡潔な記述に留め、追加の所見や影響範囲を独立項目で残さない

- `作成日` は記録を作成した日付、`実施日` は実際に試験を実施した日付として区別する
- 日付は `YYYY-MM-DD` 形式で記載する（例: `2026-11-02`）
- `実施日` にシナリオや記録の生成日を代用しない。実施日が確認できない場合は推測せず `不明` とする
- `type: validation` の検証結果は、試験を実行し、結果と根拠を確認した後にのみ作成する
- `knowledge_at/testcases/` は正式な検証記録の保存先であり、生成フェーズの仮の草案や未実施の試験記録は作成しない
- ファイル生成フェーズではシナリオ定義のみを作成し、検証記録は後続の試験実施後に別工程で作成する
- 未実施の試験について、実測値、成功・失敗判定、完了を示す記録を作成しない
- Incident と Memory Event は、実際に発生・確認した事象や状態変化がある場合にのみ記録する
- コードやシナリオの生成完了を、試験の実行完了や検証成功として記録しない

## 定期整理

定期的に次を確認します。

- 重複がないか
- 古い作業状態が残っていないか
- 再利用価値が低い情報を整理しているか
- 現在の Source of Truth が正確か

## Git 利用方針

Git は履歴管理の本体として扱います。

- 重要な状態変化は記録する
- 一時的なノイズは残さない
- 現状で必要な情報だけを Source of Truth として保つ
- 過去の詳細は履歴からたどれるようにする

## OpenWebUI でのシナリオ実行フロー

今回の利用用途では、OpenWebUI でシナリオを作成したあと、以下の流れで記録を蓄積します。

### 1. Scenario 作成

- シナリオの目的と前提を明記する
- 対象機器と実行条件を整理する
- 実行すべきコマンド、期待結果、異常時の想定を明記する
- まず ai-automation_test_docs/ で草案や生成物を作成する
- 原本は ai-automation-platform/src/user/projects/ と ai-automation-platform/src/user/libraries/ に置き、実装に伴うレポートは ai-automation-platform/src/user/generated/reports/ に出力する
- 完成した Robot シナリオは `knowledge_at/robot/`、ライブラリ実装は `knowledge_at/python/` に反映する

### 2. 実行と記録

- 実行結果を成功 / 失敗 / インシデントで分類する
- 成功した検証は `knowledge_at/testcases/` に残し、Robot シナリオは `knowledge_at/robot/`、ライブラリ実装は `knowledge_at/python/` に残す
- `knowledge_at/testcases/` は検証完了後に作成する正式記録であり、生成フェーズの試行錯誤や未実施の仮説は残さない
- 実装に伴うレポートは一時的に `ai-automation-platform/src/user/generated/reports/` に保管し、再利用価値があるものだけを `knowledge_at/` 配下の適切な記録に整理する
- 失敗や障害は `knowledge_at/incidents/` に残す
- 実行中の現状は `memory/state/` に残す

### 3. 切り分けテスト

インシデント時には、原因を絞るための追加テストを作成します。

- 追加テストは `knowledge_at/testcases/` に保存する
- 失敗の再現条件と確認項目を記録する
- どの仮説が棄却されたか、どの仮説が有効だったかを記録する

### 4. 知識化

一度は実行して終わりではなく、再利用可能な内容は以下に抽出します。

- 一般的な検証手順: `knowledge/workflows/`
- 参考情報: `knowledge/references/`
- 判定基準: `knowledge/decisions/`
- 実験・事例: `knowledge/experiments/`

## 重要な記法の統一

### 対象機能の記載

対象機能は複数項目を持てるようにし、次のように記載する。

```markdown
対象機能: インターフェース, 物理リンク, ポート
```

- 単一項目でも可
- 関連する機能や観点をまとめて記載可
- 検索しやすくするため、文言を簡潔に保つ

## Robot Framework シナリオ作成ルール

### 1. Settings セクション

- 必要なライブラリは `***Settings***` で明示する
- 外部ライブラリは、Robot ラッパーが配置されている `core/robot` などの相対パスでインポートする
- ライブラリの利用は、実行環境と依存関係が分かる形にする

例:

```robot
***Settings***
Library common.CLIExecutor    ${IP}    ${username}    ${password}    AS    CLIExecutor
```

- `Suite Setup` と `Suite Teardown` は、テスト開始前および終了時の共通処理として定義する
- 初期化や後処理が必要な場合は、キーワード化してまとめて扱う

### 2. Keywords セクション

- Python だけで表現が難しい処理や、複数の Python keyword を組み合わせて使う処理は `***Keywords***` に定義する
- Robot 側で見える名前と、Python 側の実装名を分離する
- キーワードは処理単位で分割し、テストケースが読みやすいようにする
- keyword 名は英語で命名し、日本語は使わない
- 補助関数は `_` で始める
- 新規 Keyword を作成する前に、既存の Keyword 名と処理内容を必ず確認する
- 既存 Keyword と同名、同義語、同一責務の処理を別名で作ってはいけない
- 既存 Keyword が存在する場合は、再利用または共通化を優先し、重複した新規実装を追加しない
- もし「同じ振る舞いを持つ Keyword がすでにある」と判断できたら、追加ではなく既存実装の再利用を選ぶ

例:

```text
NG: 新しい Keyword "Collect Interface Status" を作る
OK: 既存の "Get Interface Status" を再利用し、必要なら共通化する
```

これは名前が違っていても、処理が同一または実質的に重複しているものを防ぐためのルールである。

### 3. Test Cases セクション

- テストケースは工程が理解できるよう、処理を keyword 単位で分割して記述する
- 1 テストケースに多くの低レベル操作を埋め込まず、意味のあるキーワードに分ける
- 共通処理は keyword 化し、ケース本体は観点の確認に集中させる

例:

```robot
***Test Cases***
Run Show Command and Check For Invalid Output
    ${output}=    CLIExecutor.Run CLI Command    ${connection}    ${command}
```

### 4. 命名規則

- Robot keyword 名は英語で命名する
- 日本語の keyword 名は使わない
- 補助関数は `_` で始める
- Robot ファイル名は機能を表す `snake_case` を採用し、先頭の番号（例: `01-01-01_`）は必須としない
- PythonLibrary ファイル名は役割を表す `PascalCase` または `snake_case` を採用し、先頭に番号を付けない
- 既存 Keyword と重複する名前の新規作成は禁止する
- 機能が似ている場合は、別名ではなく既存実装の再利用または共通化を行う
- 生成AI は「重複の可能性がある Keyword」を作成する前に、最低 1 回は既存定義の確認を行う

## 指針

このリポジトリでは、保存量を増やすこと自体が目的ではありません。

目的は、次回の再開を正確かつ短時間で行えるようにすることです。
