---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Name Rule

## 目的

命名規則は、AI / Agent が対象を誤認しないための指針として使います。

保存先、ファイル名、キーワード名、補助関数名を一貫させることで、再利用性と保守性を高めます。

## 基本原則

1. 内容が一目で分かる名前を使う
2. 役割と責務が名前に表れるようにする
3. 同じ意味の語を重複して作らない
4. 生成AIが誤って別物を参照しないよう、命名を厳密に揃える

---

## 1. リポジトリ / ディレクトリ名

### 1.1 命名スタイル

- 小文字を使う
- 単語の区切りは `snake_case` を使う
- 日本語やスペースは使わない
- 役割が分かる単語を使う

### 1.2 例

- `device_docs`
- `knowledge_at`
- `memory/state`
- `memory/events`
- `knowledge/workflows`
- `knowledge/references`

### 1.3 ルール

- `state` は現在状態を表す
- `events` は重要な状態変化を表す
- `references` は参照資料を表す
- `decisions` は判断内容を表す
- ルートのディレクトリは大きな役割を表す
- サブディレクトリはその役割を具体化する

---

## 2. ファイル名

### 2.1 基本方針

- ファイル名は `snake_case` を使う
- 英小文字のみを使う
- 意味のある単語を使う
- 省略語は必要最小限にする

### 2.2 記録ファイル名のルール

運用上の記録ファイルは、用途が一目で分かるようにし、対象が明確になる命名にする。

- Scenario: `interface_validation_scenario.robot`
- Test case: `interface_status_check.md`
- Incident: `interface_down_incident.md`
- Knowledge: `recovery_workflow.md`

#### ルール

- 最後に目的語を置いて、内容が分かるようにする
- 日本語やスペースは使わない
- `snake_case` を採用する
- 変更履歴は Git に任せ、ファイル名で重複した意味を埋めない
- 先頭の番号（例: `01-01-01_`）は必須にしない

### 2.3 Robot Framework ファイル名

Robot Framework のテストファイルは、機能を表す `snake_case` 名で作成する。

- 形式: `<function_name>_scenario.robot`
- 例: `connect_device_scenario.robot`
- 例: `verify_interface_status.robot`
- 例: `udp_packet_loss_threshold_scenario.robot`

#### ルール

- ファイル名は `snake_case` を使う
- 日本語やスペースは使わない
- `template` などの汎用名は、必要に応じて機能名を後ろに書いて区別する
- 先頭の番号（例: `01-01-01_`）は使ってもよいが、運用上は不要とする

### 2.4 PythonLibrary ファイル名

PythonLibrary のファイル名は、Robot から利用する役割が分かる命名にする。

- 形式: `<RoleName>Library.py` または `<role_name>_library.py`
- 例: `UDPCommunicationValidationLibrary.py`
- 例: `interface_status_library.py`

#### ルール

- 先頭に番号（例: `01-01-01_`）を付けない
- ファイル名は役割を表す語を使う
- `Library` サフィックスや `_library` を付けて用途を明確にする

---

## 3. Robot Framework keyword 名

Robot Framework で利用する keyword 関数は、Python 内部関数名ではなく、Robot 側で参照される名を `@keyword('<名前>')` で明示する。

- `from robot.api.deco import keyword` を使う
- Robot から見える名前は、テストケースで読みやすい英語または業務用語にする
- 日本語の keyword 名は使わない
- keyword 名は動作が一目で分かるようにする
- 曖昧な一般名や抽象名を避ける
- 同じ意味の keyword を重複して作らない
- 1 つの keyword には 1 つの責務だけを持たせる
- 実装関数名と Robot の参照名は分離する

### 3.1 既存 Keyword と重複しないためのルール

新規の Keyword を作成する前に、まず既存の Keyword 名、公開名、責務、呼び出し箇所を確認する。

- 既存 Keyword と同じ公開名を使ってはいけない
- 既存 Keyword と同じ意味や処理を別名で作ってはいけない
- 似た機能が既にある場合は、新規作成ではなく既存 Keyword の再利用かリファクタリングを優先する
- 処理内容が重複していると判断できる場合は、共通化して 1 つの Keyword に集約する
- 既存実装に同じ責務があるにもかかわらず、新しい Keyword を追加するのは禁止する
- 既存の Keyword を確認できない状態で新規作成を進めてはいけない

これは「名前が違うだけで実質的に同じ処理」を作ってしまうことを防ぐための必須ルールである。

### 例

```python
from robot.api.deco import keyword

@keyword('Connect Device')
def connect_device():
    pass

@keyword('Collect Interface Status')
def collect_interface_status():
    pass
```

Robot からは `Connect Device` や `Collect Interface Status` として呼び出されるため、テストケース側で意味が明確になる。

---

## 4. 補助関数の命名

Robot Framework で直接呼ばれない補助関数は、先頭をアンダースコアにする。

- 例: `_get_value()`
- 例: `_build_request_payload()`

### ルール

- keyword として公開しない関数は `_` から始める
- その関数は内部処理専用と扱う
- Robot のテストケースから直接呼ばれないようにする
- 補助関数の名前も、役割が分かる英語にする

---

## 5. 禁止事項

- 日本語の keyword 名を使わない
- 抽象名を使いすぎない
- 似た意味の複数名を作らない
- 暗黙的な略称を多用しない
- Robot keyword は「内部名」ではなく「Robot 上の参照名」を優先する
- 役割が重複するファイルや関数を増やし続けない
- 既存 Keyword と同名または同一責務の Keyword を新規作成してはいけない
- 同じ動作を別名で持つ Keyword を作ることを禁止する
- 既存実装を確認せずに新規 keyword を追加してはいけない

---

## 6. 命名の優先順

1. 役割が分かる名前
2. 実行内容が明確な名前
3. 既存ルールとの整合
4. 一貫した英語表現

これにより、AI が生成したコードと手書きコードが自然に同じ命名規則に従える。
