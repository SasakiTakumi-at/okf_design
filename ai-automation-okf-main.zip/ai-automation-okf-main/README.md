---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# ai-automation-okf

このリポジトリは、ワークスペース全体の一部として運用する OKF（Open Knowledge Format）です。

重要なのは、OKF は単独で完結する独立リポジトリではなく、ワークスペース上の複数リポジトリ・作業領域と連携して機能する構成要素である点です。

この `ai-automation-okf` リポジトリ自体の実体は、以下のディレクトリ群で構成されています。

```text
.
├── README.md
├── docs/
├── generator/
├── instructions/
├── okf_repository/
├── .git/
└── ...
```

一方で、実運用では `ai-automation-platform/`、`ai-automation_test_docs/`、`ai-automation_pf_harness/` などのディレクトリは、当リポジトリの内部ではなく、ワークスペース上の関連リポジトリまたは作業領域として並立して扱います。

最新のワークスペース構成は、実際のディレクトリ構成と本書の説明を一致させたものを基準とします。以下の構成図は、OKF を含むワークスペース全体の関係を示すものであり、当リポジトリの実際のディレクトリ配置そのものではないことに注意してください。

## ワークスペース全体の 4 リポジトリ構成

このワークスペースで運用する主要な 4 リポジトリは、次のとおりです。

```text
.
├── ai-automation-platform/         # 実行基盤・自動化実装領域
│   ├── src/                       # 実行基盤とソースコードの中心
│   │   ├── core/                  # 共通基盤（ansible / network / event / models / robot）
│   │   │   └── robot/
│   │   │       └── libs/
│   │   ├── main/                  # 実行入口と制御
│   │   └── user/                  # 実装・生成・プロジェクトの作業領域
│   │       ├── generated/          # Robot/Python 原本とレポートの作業領域
│   │       │   ├── projects/
│   │       │   ├── libraries/
│   │       │   └── reports/
│   │       ├── projects/
│   │       ├── platforms/
│   │       ├── libraries/
│   │       └── user_platforms.py
│   └── README.md
│
├── ai-automation_test_docs/        # ユーザー操作・手順書・計画書の作業領域
│   ├── profiles/
│   ├── test_plan/
│   ├── test_procedure/
│   └── README.md
│
├── ai-automation-okf/              # OKF の保存・再利用・知識管理領域
│   ├── README.md
│   ├── docs/
│   │   ├── README.md
│   │   ├── INDEX.md
│   │   ├── AGENTS.md
│   │   ├── ARCHITECTURE.md
│   │   ├── DEVELOPMENT_GUIDE.md
│   │   ├── GLOSSARY.md
│   │   ├── NAME_RULE.md
│   │   └── SPEC.md
│   ├── generator/
│   │   ├── generate_code.py
│   │   └── prompts.py
│   ├── instructions/
│   │   ├── README.md
│   │   ├── level-1-custom-instructions.md
│   │   └── memory-consolidation-prompt.md
│   ├── okf_repository/
│   │   ├── README.md
│   │   ├── memory/
│   │   │   ├── README.md
│   │   │   ├── events/
│   │   │   └── state/
│   │   ├── knowledge_at/
│   │   │   ├── INDEX.md
│   │   │   ├── incidents/
│   │   │   ├── robot/
│   │   │   ├── python/
│   │   │   └── testcases/
│   │   ├── knowledge/
│   │   │   ├── INDEX.md
│   │   │   ├── workflows/
│   │   │   ├── references/
│   │   │   ├── decisions/
│   │   │   └── experiments/
│   │   ├── device_docs/
│   │   └── template/
│   └── .git/
│
├── ai-automation_pf_harness/       # 実行支援ハーネス領域
│   ├── main.py
│   ├── general.yml
│   ├── .secret.yml
│   ├── agents/
│   │   ├── agent_builder.py
│   │   ├── router/
│   │   ├── normal_chat/
│   │   ├── info/
│   │   ├── test_plan_path_finder/
│   │   ├── test_plan_gate/
│   │   └── test_plan_builder/
│   ├── tools/
│   │   ├── tool_registry.py
│   │   ├── mcpo_tool_loader.py
│   │   └── local/
│   ├── utils/
│   │   ├── settings_loader.py
│   │   ├── git_repository.py
│   │   ├── checkpoint_cleanup.py
│   │   ├── open_webui_client.py
│   │   └── logger.py
│   ├── workflow/
│   │   ├── graph.py
│   │   ├── nodes.py
│   │   ├── edges.py
│   │   ├── state.py
│   │   ├── context.py
│   │   ├── schemas/
│   │   ├── info_workflow/
│   │   └── test_workflow/
│   └── README.md
│
└── ai_automation_repos.md          # ワークスペース全体の構成メモ（補助資料）
```

この 4 つは、ワークスペース全体の責務分離を表す基本構成です。

- `ai-automation-platform/` : 実装・生成・検証の実体
- `ai-automation_test_docs/` : 手順書・テスト計画・草案の作業領域
- `ai-automation-okf/` : 外部メモリーと知識の正式保存先
- `ai-automation_pf_harness/` : 実行支援と連携の補助基盤

## 役割

OKF は、会話全文そのものを保存するのではなく、次回の作業を再開するために必要な現在状態と、再利用可能な知識を分離して管理するための仕組みです。

このリポジトリでは、以下のような情報を管理します。

- 現在の作業状態
- 実施した検証の事実
- 発生したインシデント
- 原因切り分けの結果
- 再利用可能な判断基準と手順
- 機器・環境ごとの参照資料

## ai-automation-platform の役割と実務ルール

ai-automation-platform は、OKF の実装側に相当する実行基盤です。ここでは「検証対象の自動化ロジック」「Robot シナリオ」「Python 実装」「レポート」「プロジェクト固有の設定」を管理し、OKF はその結果を再利用可能な知識として整理します。

実際の構成は次の通りです。

- src/core/: 実行基盤と共通処理の中心
  - ansible/, network/, event/, models/ などの共通要素
  - robot/ は Robot / Library の共通基盤と実行インターフェースを保持する
- src/main/: エントリポイントと起動制御
- src/user/generated/: 生成中の原本置き場
  - projects/: Robot シナリオ原本
  - libraries/: Python 実装原本
  - reports/: 実装に伴う判断・検証メモ
- src/user/projects/: 実際のプロジェクトや試験対象の構成
- src/user/platforms/ と src/user/libraries/: 具象化した platform / reusable library 実装

シナリオ生成時の基本ルールは次の通りです。

1. 生成物の原本は ai-automation-platform/src/user/projects/ または ai-automation-platform/src/user/libraries/ に置く
2. 実行・検証に必要な検証ログや判定メモは reports/ に一時保存する
3. 再利用価値がある成果物だけを ai-automation-okf/okf_repository/knowledge_at/ に反映する
4. 永続化すべき知識は knowledge/ と knowledge_at/ に分離して整理する
5. 実環境依存の値や機器名は、固定値の埋め込みではなく設定化する

このルールを守ることで、生成対象の原本と正式記録が区別され、シナリオ生成時に参照対象がぶれません。

## 利用フィロー

大まかな運用は次の流れです。

1. ユーザーが ai-automation_test_docs/test_procedure/ に手順書の原本を置く
2. ユーザーまたは LLM / Agent が ai-automation_test_docs/test_plan/ に実行計画書の原本を置き、更新・調整する
3. Robot などの生成物は ai-automation-platform/src/user/projects/ で原本を作成・編集し、Python 実装も ai-automation-platform/src/user/libraries/ で原本を作成・編集する
4. 実装と同時に、設計判断・検証結果・要点整理を ai-automation-platform/src/user/generated/reports/ にレポートとして出力する
5. 生成後に完成した成果物のうち、再利用に値するものだけを okf_repository/knowledge_at/robot/、knowledge_at/python/、または適切な knowledge_at 配下へ記録フォーマットに沿って書き出す
6. 再利用可能な知識は knowledge/ に整理する
7. 現在状態と重要イベントは memory/ に保持する

> 手順書・実行計画書・Robot 原本は、それぞれ作業用の原本として別リポジトリまたは一時作業領域に保持する。実装時に出力されるレポートは ai-automation-platform/src/user/generated/reports/ に一時保存し、再利用に値する情報だけを knowledge_at の記録フォーマットへ落とし込む。元の原本そのものをそのまま正式保存先へ移すのではなく、再利用に適した記録として書き出す。

## リポジトリ構成

このリポジトリ自体の実体は、以下のディレクトリで構成されています。

```text
.
├── README.md
├── docs/
├── generator/
├── instructions/
├── okf_repository/
├── .git/
└── ...
```

一方で、ワークスペース全体の利用時には、以下のような関連レポジトリや作業領域が並立して運用されます。

```text
.
├── ai-automation-platform/        # 実行基盤と自動化処理
├── ai-automation_test_docs/        # 手順書・計画・草案の作業領域
├── ai-automation-okf/              # OKF の保存・再利用領域
├── ai-automation_pf_harness/       # 実行支援ハーネス
└── ...
```

> 上の構成図はワークスペース全体の関係を示すものであり、`ai-automation-okf` リポジトリ内部の実体ではありません。実際の OKF リポジトリ本体は `docs/`、`generator/`、`instructions/`、`okf_repository/` を含む構成です。

## 主要ドキュメント

- [docs/README.md](./docs/README.md)  — OKF の設計意図と利用全体像
- [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md) — 責務分離と保存先の設計
- [docs/DEVELOPMENT_GUIDE.md](./docs/DEVELOPMENT_GUIDE.md) — Read / Write フローと運用ルール
- [okf_repository/README.md](./okf_repository/README.md) — 実運用用の外部メモリー構成

## 基本方針

- Memory は現在の状態を保持する
- Knowledge は再利用可能な知識を保持する
- Knowledge_at は具体的な事例・シナリオ・インシデント・検証結果を残す
- device_docs はベンダーや機器別の参照資料を管理する
- template は再利用する雛形を管理する
- 一時的な生成物は ai-automation_test_docs/ で整理し、完了時に OKF へ反映する
- Git による履歴管理と重複整理を行う

## 補足

このリポジトリは、OKF の設計思想と運用原則を説明するための資料集であり、実際の自動化検証や生成作業は、ワークスペース内の他リポジトリと連携して行います。

詳細な設計と運用ルールは、docs 配下の各資料を参照してください。