---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Memory

この領域は、対象環境や利用者に固有な「現在状態」と「重要な状態遷移」を管理するための OKF Bundle です。

## 役割

- `state/` : 現在の状態を保持する
- `events/` : 重要な変更や節目を記録する

## 基本方針

- 会話の全文をそのまま記録しない
- 次回の作業再開に必要な情報だけを残す
- 現在の Source of Truth を維持する
- 経過的な細かい変更は Git 履歴へ委ねる

## 参照先

- [state/index.md](./state/index.md)
- [events/index.md](./events/index.md)
- [../README.md](../README.md)
