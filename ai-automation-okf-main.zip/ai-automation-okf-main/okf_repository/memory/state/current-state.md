---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Current State

## 1. 現在のテーマ

ネットワーク機器の自動化検証を継続中。OpenWebUI でシナリオを作成し、インターフェース状態確認と設定確認を実施している。

## 2. 進行中の作業

- インターフェース状態確認シナリオを実行中
- 失敗時に切り分けテストを追加予定
- 成功した検証結果を Knowledge_at に蓄積する

## 3. 現在の設定・値

- 対象機器: Access Switch
- 実行方式: Robot Framework を利用した CLI 検証
- 実行時の接続先: 管理用 IP と playbook 配置済み
- 確認観点: interface status / log output / configuration diff

## 4. 制約事項

- 重要な設定値や認証情報は記録しない
- 追加の切り分けテストは最小対象に限定する
- 実行結果は成功・失敗・インシデントを明確に分ける

## 5. 次に行うこと

- インターフェース異常時の再現手順を確認する
- 失敗原因を切り分けする追加チェックを作成する
- 再利用可能な知見を Knowledge に抽出する
