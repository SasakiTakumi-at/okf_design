---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# OKF Repository

このディレクトリは、ai-automation-okf の実運用用外部メモリー領域です。

ここで管理するのは、現在状態・重要イベント・再利用可能な知識・実行事例・インシデントの正式保存先です。生成や編集の一時作業は `ai-automation_test_docs/` や関連リポジトリで行い、作業完了時にこの領域へ反映します。

> `okf_repository/` の中身はこのリポジトリ内部に実際に存在する保存先ですが、手順書の原本や実装の草案は同じワークスペース上の関連ディレクトリに置く前提です。リポジトリ本体と、ワークスペース全体の関連作業領域は役割が分離されます。

## 役割分担

- `memory/` : 現在の状態と重要な変化
- `knowledge_at/` : 実行した Robot シナリオ、Python ライブラリ実装、インシデント、切り分けテスト
- `knowledge/` : 汎用的な手順・判断・参考知識
- `device_docs/` : ベンダー別の参照資料
- `template/` : 実行記録や生成物の雛形

## 保存例

```text
okf_repository/
├── README.md
├── memory/
│   ├── README.md
│   ├── events/
│   │   ├── README.md
│   │   └── important-change.md
│   └── state/
│       ├── README.md
│       └── current-state.md
├── knowledge_at/
│   ├── INDEX.md
│   ├── incidents/
│   │   └── interface_down_incident.md
│   ├── robot/
│   │   └── interface_validation_scenario.robot
│   ├── python/
│   │   └── InterfaceValidationLibrary.py
│   └── testcases/
│       └── interface_status_check.md
├── knowledge/
│   ├── INDEX.md
│   ├── workflows/
│   │   ├── INDEX.md
│   │   └── interface_recovery_workflow.md
│   ├── references/
│   │   └── INDEX.md
│   ├── decisions/
│   │   └── INDEX.md
│   └── experiments/
│       └── INDEX.md
├── device_docs/
│   ├── INDEX.md
│   └── ...
├── template/
│   ├── INDEX.md
│   ├── incident_template.md
│   ├── robot_template.robot
│   ├── testcase_template.md
│   └── README.md
└── README.md
```

## 基本原則

- 実行中の状態は `memory/` に保持する
- 実際の生成・編集は ai-automation_test_docs/ で扱い、完了時に `knowledge_at/` に格納・反映する
- シナリオや事例は `knowledge_at/` に保持する
- 一般化可能な知識は `knowledge/` に抽出する
- 成功・失敗・インシデントを区別して記録する
- 重要な変化だけをイベントとして残す
- Git 履歴で過去の変更を追跡する
