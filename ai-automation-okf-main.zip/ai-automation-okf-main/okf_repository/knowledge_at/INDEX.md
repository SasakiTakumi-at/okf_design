---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Knowledge_at Index

この領域には、特定のシナリオ、検証ケース、インシデント、切り分けテストの記録を蓄積する。

## 目的

- OpenWebUI で作成したシナリオを保持する
- 実行結果を成功・失敗・インシデントで分けて管理する
- 環境依存の事例やトラブル詳細を再利用しやすい形で残す
- 汎用化前の実運用知見を記録し、後で `knowledge/` へ抽出できるようにする

## 保存先の例

- `robot/interface_validation_scenario.robot`
- `python/InterfaceValidationLibrary.py`
- `testcases/interface_status_check.md`
- `incidents/interface_down_incident.md`

## 運用ルール

- 草案・設計・実装・レポートの一時編集は `ai-automation_test_docs/` で行い、完了時に `knowledge_at/` に格納・反映する
- シナリオと実行結果は分離して管理する
- 成功した検証は再利用可能なパターンとして残す
- 失敗や障害は再現条件、影響範囲、原因、切り分け結果を明確に記録する
- 切り分けテストは仮説と結果を分けて残す
- 環境依存の情報は `knowledge_at/` に残し、汎用化できる内容は `knowledge/` へ抽出する
- 各記録には `Tags` / `Related Keywords` / `Referenced Sources` を付けて関連情報へ辿れるようにする
- `Referenced Sources` には、作成時に参照した手順書、コマンド、ログ、ドキュメント、既存記録を残す
- OKF 内の任意のファイルを参照元にできる。既存の template、knowledge、device_docs、memory、docs なども、根拠として扱った場合は必ず記載する
- タグは小文字の `snake_case` に統一し、検索しやすい語を使う

## Metadata の例

```markdown
## Metadata
- Tags: interface, link_down, triage
- Related Keywords: show_interface_status, interface_status, check_link_state
- Referenced Sources: okf_repository/device_docs/cisco/iosxe_command_reference.md, show interfaces status, interface_down_2026_11_04.log
```

## 管理方針

- Robot シナリオの原本は `robot/` に保存する
- Python のライブラリ実装や Keyword 実装は `python/` に保存する
- 成功した検証結果は `testcases/` に残す
- 障害や異常の記録は `incidents/` に残す
- 再利用価値がある内容は `knowledge/` へ一般化して整理する
