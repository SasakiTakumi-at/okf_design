# Metadata
# Tags: udp, packet_loss, bandwidth_threshold, binary_search, validation
# Related Keywords: iperf, packet_loss_rate, threshold_search, udp_communication
# Referenced Sources: ai-automation_test_docs/procedure/手順書.txt, docs/DEVELOPMENT_GUIDE.md, docs/NAME_RULE.md, okf_repository/knowledge/workflows/01-01-01_udp_packet_loss_threshold_workflow.md

*** Settings ***
Library    SSHLibrary
Library    Collections

Suite Setup    Connect To Test Devices
Suite Teardown    Close All Sessions

*** Variables ***
${ROUTER1_HOST}        router1
${ROUTER1_USER}        admin
${ROUTER1_PASSWORD}    ${EMPTY}
${SERVER_HOST}         iperf-server
${SERVER_USER}         admin
${SERVER_PASSWORD}     ${EMPTY}
${CLIENT_HOST}         iperf-client
${CLIENT_USER}         admin
${CLIENT_PASSWORD}     ${EMPTY}
${TARGET_INTERFACE}     GigabitEthernet0/4
${LOSS_THRESHOLD}      5
${STOP_DELTA_MBPS}     10
${LOWER_BOUND}         0
${UPPER_BOUND}         1000

*** Keywords ***
Connect To Test Devices
    Open Connection    ${ROUTER1_HOST}
    Login    ${ROUTER1_USER}    ${ROUTER1_PASSWORD}
    Open Connection    ${SERVER_HOST}
    Login    ${SERVER_USER}    ${SERVER_PASSWORD}
    Open Connection    ${CLIENT_HOST}
    Login    ${CLIENT_USER}    ${CLIENT_PASSWORD}

Capture Baseline
    ${running_config}=    Execute Command    show running-config
    ${baseline_interface}=    Execute Command    show interface ${TARGET_INTERFACE}
    ${process_cpu}=    Execute Command    show process cpu
    ${process_resources}=    Execute Command    show process resources
    Log    Baseline captured for ${TARGET_INTERFACE}
    Set Suite Variable    ${running_config}
    Set Suite Variable    ${baseline_interface}
    Set Suite Variable    ${process_cpu}
    Set Suite Variable    ${process_resources}

Clear Interface Counters
    Execute Command    clear counters ${TARGET_INTERFACE}
    Log    Interface counters cleared on ${TARGET_INTERFACE}

Run UDP Traffic At Bandwidth
    [Arguments]    ${bandwidth_mbps}
    Log    Execute UDP iperf traffic at ${bandwidth_mbps} Mbps
    ${iperf_result}=    Execute Command    iperf3 -u -c ${CLIENT_HOST} -b ${bandwidth_mbps}M -t 30
    Log    iperf result: ${iperf_result}
    [Return]    ${iperf_result}

Analyze Packet Loss
    [Arguments]    ${interface_after}
    ${loss_percent}=    Extract Loss Percentage    ${interface_after}
    ${output_packets_after}=    Extract Output Packets    ${interface_after}
    ${output_packets_before}=    Extract Output Packets    ${baseline_interface}
    ${packet_delta}=    Evaluate    ${output_packets_after} - ${output_packets_before}

    IF    ${loss_percent} < ${LOSS_THRESHOLD}
        ${decision}=    Set Variable    NO_LOSS
    ELSE
        ${decision}=    Set Variable    LOSS
    END

    Log    loss_percent=${loss_percent}, packet_delta=${packet_delta}, decision=${decision}
    [Return]    ${decision}    ${loss_percent}    ${packet_delta}

Extract Loss Percentage
    [Arguments]    ${interface_output}
    ${loss_percent}=    Evaluate    0
    ${loss_value}=    Get Regexp Matches    ${interface_output}    (?i)lost/total.*?([0-9]+\.?[0-9]*)\s*%?
    IF    ${loss_value}
        ${loss_percent}=    Set Variable    ${loss_value[0]}
    END
    [Return]    ${loss_percent}

Extract Output Packets
    [Arguments]    ${interface_output}
    ${output_packets}=    Get Regexp Matches    ${interface_output}    (?i)output packets:\s*([0-9]+)
    IF    ${output_packets}
        ${packet_count}=    Set Variable    ${output_packets[0]}
    ELSE
        ${packet_count}=    Set Variable    0
    END
    [Return]    ${packet_count}

Update Search Bound
    [Arguments]    ${lower_bound}    ${upper_bound}    ${test_bandwidth}    ${decision}
    IF    '${decision}' == 'NO_LOSS'
        ${new_lower}=    Set Variable    ${test_bandwidth}
        ${new_upper}=    Set Variable    ${upper_bound}
    ELSE
        ${new_lower}=    Set Variable    ${lower_bound}
        ${new_upper}=    Set Variable    ${test_bandwidth}
    END
    [Return]    ${new_lower}    ${new_upper}

Find UDP Packet Loss Threshold
    Capture Baseline
    ${lower_bound}=    Set Variable    ${LOWER_BOUND}
    ${upper_bound}=    Set Variable    ${UPPER_BOUND}

    WHILE    ${upper_bound} - ${lower_bound} > ${STOP_DELTA_MBPS}
        ${test_bandwidth}=    Evaluate    (${lower_bound} + ${upper_bound}) / 2
        Log    Testing bandwidth ${test_bandwidth} Mbps
        ${iperf_result}=    Run UDP Traffic At Bandwidth    ${test_bandwidth}
        ${interface_after}=    Execute Command    show interface ${TARGET_INTERFACE}
        ${decision}    ${loss_percent}    ${packet_delta}=    Analyze Packet Loss    ${interface_after}
        ${lower_bound}    ${upper_bound}=    Update Search Bound    ${lower_bound}    ${upper_bound}    ${test_bandwidth}    ${decision}
        Log    lower_bound=${lower_bound}, upper_bound=${upper_bound}, decision=${decision}, loss_percent=${loss_percent}
    END

    Set Suite Variable    ${threshold_bandwidth}    ${upper_bound}
    Log    Detected threshold bandwidth: ${threshold_bandwidth} Mbps

*** Test Cases ***
UDP Packet Loss Threshold Search
    Connect To Test Devices
    Clear Interface Counters
    Find UDP Packet Loss Threshold
    Should Be True    ${threshold_bandwidth} >= 0
    Log    Threshold search complete. Final upper bound is ${threshold_bandwidth} Mbps.
