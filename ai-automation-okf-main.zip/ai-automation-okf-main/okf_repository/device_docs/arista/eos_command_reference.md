---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Arista EOS コマンドリファレンス

## 概要

- ベンダー: Arista
- OS: EOS
- 主な用途: L2/L3 スイッチ、アクセス/コアの運用確認、障害切り分け
- 記載方針: 実運用で頻繁に使う確認コマンドを中心に整理する

## 1. 接続と基本確認

```bash
show version
show hostname
show clock
show system environment cooling
show system environment temperature
show inventory
```

- `show version`: EOS バージョン、ハードウェア情報、起動イメージの確認
- `show hostname`: 実際のホスト名の確認
- `show clock`: 時刻確認
- `show system environment cooling`: 冷却状態の確認
- `show inventory`: モジュールやラインカードの確認

## 2. インターフェース状態確認

```bash
show interfaces status
show interfaces counters
show interfaces transceiver
show ip interface brief
show ipv6 interface brief
show interfaces description
```

- `show interfaces status`: 物理インターフェースの状態確認
- `show interfaces counters`: 通信量やエラー数の確認
- `show interfaces transceiver`: 光モジュールの状態確認
- `show ip interface brief`: IP アドレスと状態の簡易確認
- `show interfaces description`: インターフェース説明の確認

## 3. 設定確認と保存

```bash
show running-config
show startup-config
show running-config interface Ethernet1
show pending
copy running-config startup-config
write memory
```

- `show running-config`: 現在の設定確認
- `show startup-config`: 起動時設定の確認
- `copy running-config startup-config`: 設定を保存
- `write memory`: 設定保存の短縮コマンド

## 4. VLAN と L2 ループ確認

```bash
show vlan
show vlan brief
show mac address-table
show mac address-table dynamic
show spanning-tree summary
show spanning-tree vlan 1
show port-channel summary
```

- `show vlan`: VLAN 情報
- `show mac address-table`: MAC アドレス学習状況
- `show spanning-tree summary`: STP の状態確認
- `show port-channel summary`: Port-Channel の状態確認

## 5. L3 ルーティング確認

```bash
show ip route
show ip route summary
show ip bgp summary
show ipv6 route
show ip ospf neighbor
show ip ospf database
show ip bgp neighbors
```

- `show ip route`: ルーティングテーブルの確認
- `show ip bgp summary`: BGP の状態確認
- `show ip ospf neighbor`: OSPF 隣接状態確認
- `show ipv6 route`: IPv6 ルート確認

## 6. LLDP / CDP / 親和性確認

```bash
show lldp neighbors
show lldp neighbors detail
show cdp neighbors
show cdp neighbors detail
```

- `show lldp neighbors`: 隣接機器の確認
- `show lldp neighbors detail`: 詳細情報確認

## 7. ルーティング / フラッティング確認

```bash
ping 192.168.1.1
traceroute 192.168.1.1
show ip arp
show ip dhcp snooping binding
show ip access-lists
```

- `ping`: L3 接続確認
- `traceroute`: 経路確認
- `show ip arp`: ARP テーブル確認
- `show ip access-lists`: ACL 状態確認

## 8. 重大障害時の確認

```bash
show logging
show log last 50
show processes top once
show system environment all
show interfaces counters errors
show interface Ethernet1 transceiver
```

- `show logging`: ログの確認
- `show interfaces counters errors`: エラーの確認
- `show processes top once`: CPU やリソースの異常確認

## 9. 設定変更時の基本コマンド

```bash
configure terminal
interface Ethernet1
description UPLINK-TO-CORE
no shutdown
ip address 10.0.0.1/24
exit
copy running-config startup-config
```

- 設定変更の基本流れは `configure terminal` から開始する
- `no shutdown` でインターフェースを有効化する
- 終了後に設定保存を忘れない

## 10. よく使う確認優先順位

1. `show version`
2. `show interfaces status`
3. `show ip interface brief`
4. `show running-config`
5. `show logging`
6. `show ip route`
7. `show mac address-table`
8. `show spanning-tree summary`
9. `show interfaces counters`
10. `show processes top once`

## 11. 実運用での判断ポイント

- インターフェースが `connected` でない場合は物理 or VLAN 設定を確認する
- `show interfaces counters` でエラーが増えている場合は、ケーブル・トランシーバー・リンクの状態を確認する
- `show ip route` で経路が欠落している場合は、OSPF/BGP などの隣接状態を確認する
- `show logging` は障害発生直後の切り分けで最優先に見る
