---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Cisco IOS XE コマンドリファレンス

## 概要

- ベンダー: Cisco
- OS: IOS XE
- 主な用途: ルータ / スイッチ / WAN 機器の運用確認
- 記載方針: 一般的な診断と設定確認でよく使うコマンドを中心に整理する

## 1. 接続と基本確認

```bash
show version
show clock
show inventory
show platform
show environment
show processes cpu sorted
```

- `show version`: IOS XE バージョンとハードウェア確認
- `show platform`: ハードウェア状態とカード情報確認
- `show environment`: 温度や電源状態の確認
- `show processes cpu sorted`: CPU 使用率確認

## 2. インターフェース状態確認

```bash
show interfaces status
show ip interface brief
show ipv6 interface brief
show interfaces description
show interfaces counters
show interfaces transceiver
```

- `show interfaces status`: インターフェース状態確認
- `show ip interface brief`: IP アドレスと状態の確認
- `show interfaces counters`: エラー数や通過量確認
- `show interfaces transceiver`: 光モジュール状態確認

## 3. 設定確認と保存

```bash
show running-config
show startup-config
show running-config interface GigabitEthernet0/1
copy running-config startup-config
wr mem
```

- `show running-config`: 現在設定の確認
- `show startup-config`: 起動設定の確認
- `copy running-config startup-config`: 保存
- `wr mem`: 保存の短縮コマンド

## 4. VLAN / L2 確認

```bash
show vlan brief
show mac address-table
show spanning-tree summary
show port-channel summary
show etherchannel summary
```

- `show vlan brief`: VLAN 一覧確認
- `show mac address-table`: MAC 学習状態確認
- `show spanning-tree summary`: STP 状態確認
- `show etherchannel summary`: EtherChannel 状態確認

## 5. L3 / ルーティング確認

```bash
show ip route
show ip route summary
show ip ospf neighbor
show ip ospf database
show ip bgp summary
show ip eigrp neighbors
show ip cef summary
```

- `show ip route`: ルーティングテーブル確認
- `show ip ospf neighbor`: OSPF 隣接確認
- `show ip bgp summary`: BGP の状態確認
- `show ip eigrp neighbors`: EIGRP 隣接確認

## 6. ネットワーク診断

```bash
ping 192.168.1.1
traceroute 192.168.1.1
show ip arp
show ip dhcp snooping binding
show access-lists
show ip access-lists
```

- `ping`: L3 接続確認
- `traceroute`: 経路確認
- `show ip arp`: ARP 確認
- `show access-lists`: ACL の確認

## 7. ログと障害切り分け

```bash
show logging
show log
show logging last 50
show archive log config all
show tech-support
```

- `show logging`: ログの確認
- `show tech-support`: 診断情報収集
- `show logging last 50`: 直近ログの確認

## 8. 設定変更の基本

```bash
configure terminal
interface GigabitEthernet0/1
description UPLINK-TO-CORE
no shutdown
ip address 10.0.0.1 255.255.255.0
exit
wr mem
```

- `configure terminal` で設定モードに入る
- `no shutdown` でインターフェース有効化
- `wr mem` で保存する

## 9. よく使う確認優先順位

1. `show version`
2. `show interfaces status`
3. `show ip interface brief`
4. `show running-config`
5. `show logging`
6. `show ip route`
7. `show mac address-table`
8. `show spanning-tree summary`
9. `show interfaces counters`
10. `show processes cpu sorted`

## 10. 実運用での判断ポイント

- インターフェースが `administratively down` なら設定の有効化状態を確認する
- `show interfaces counters` で CRC / input errors が増えている場合は、ケーブルやトランシーバーを確認する
- `show ip route` で欠落がある場合は OSPF/BGP の隣接状態を確認する
- `show logging` は障害直後の切り分けで最優先に見る
