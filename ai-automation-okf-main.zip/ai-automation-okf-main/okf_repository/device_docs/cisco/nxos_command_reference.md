---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Cisco NX-OS コマンドリファレンス

## 概要

- ベンダー: Cisco
- OS: NX-OS
- 主な用途: データセンター、スイッチング基盤、L2/L3 の運用確認
- 記載方針: スイッチング環境で特に頻繁に使う確認コマンドを中心に整理する

## 1. 接続と基本確認

```bash
show version
show hostname
show clock
show module
show system redundancy status
show environment
```

- `show version`: NX-OS バージョンとハードウェア情報
- `show module`: モジュール状態確認
- `show environment`: 温度や電源チェック
- `show system redundancy status`: 冗長構成確認

## 2. インターフェース状態確認

```bash
show interface status
show interface brief
show interface Ethernet1/1
show interface counters
show hardware internal errors
```

- `show interface status`: インターフェースの状態確認
- `show interface brief`: 主要状態の簡易確認
- `show interface counters`: 通信量とエラー数の確認
- `show hardware internal errors`: 内部エラー確認

## 3. VLAN / L2 確認

```bash
show vlan brief
show vlan
show mac address-table
show port-channel summary
show spanning-tree summary
show fabric forwarding
```

- `show vlan brief`: VLAN 一覧確認
- `show mac address-table`: MAC 学習情報確認
- `show port-channel summary`: Port-Channel 確認
- `show spanning-tree summary`: STP 確認

## 4. L3 / ルーティング確認

```bash
show ip route
show ip route summary
show ip ospf neighbor
show ip ospf interface brief
show ip bgp summary
show ipv6 route
show vrf
```

- `show ip route`: ルーティングテーブル確認
- `show ip ospf neighbor`: OSPF 隣接確認
- `show ip bgp summary`: BGP 状態確認
- `show vrf`: VRF の確認

## 5. 近隣情報確認

```bash
show cdp neighbors
show cdp neighbors detail
show lldp neighbors
show lldp neighbors detail
```

- `show cdp neighbors`: 隣接機器確認
- `show lldp neighbors`: LLDP による接続情報確認

## 6. 設定確認と保存

```bash
show running-config
show startup-config
show running-config interface Ethernet1/1
copy running-config startup-config
write memory
```

- `show running-config`: 現在設定の確認
- `copy running-config startup-config`: 設定保存
- `write memory`: 短縮保存コマンド

## 7. 回線診断と障害切り分け

```bash
ping 192.168.1.1
traceroute 192.168.1.1
show logging
show log
show system resources
show processes cpu
show hardware profile status
```

- `ping`: 接続確認
- `traceroute`: 経路確認
- `show logging`: ログ確認
- `show system resources`: リソース状況確認
- `show processes cpu`: CPU 使用率確認

## 8. 設定変更の基本

```bash
configure terminal
interface Ethernet1/1
description UPLINK-TO-CORE
no shutdown
switchport mode access
switchport access vlan 100
exit
copy running-config startup-config
```

- `configure terminal` で設定モードへ遷移
- `switchport mode access` で Access ポート化
- `no shutdown` を忘れない
- 保存を行う

## 9. よく使う確認優先順位

1. `show version`
2. `show interface status`
3. `show interface brief`
4. `show vlan brief`
5. `show mac address-table`
6. `show ip route`
7. `show logging`
8. `show port-channel summary`
9. `show system resources`
10. `show processes cpu`

## 10. 実運用での判断ポイント

- インターフェースが `down` または `suspended` の場合は、物理状態と VLAN 設定を確認する
- `show mac address-table` を見て学習がない場合は、ポート制約やトランキング状態を確認する
- `show ip route` の欠落がある場合は OSPF/BGP の隣接状態を確認する
- `show logging` は設定変更や障害時の最重要ログの1つである

> なお、一部のコマンドは機種・ソフトウェアのバージョンで差異があるため、対象機器の正確な CLI 形式と併せて確認する。
