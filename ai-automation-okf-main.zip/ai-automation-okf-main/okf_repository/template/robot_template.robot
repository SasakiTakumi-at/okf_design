*** Settings ***
# 必要なLibraryファイル(Python形式)をimport
Library    NetworkLibrary.py

# Test開始および終了処理がある場合
Suite Setup    Open All Sessions    ${ssh_targets}
Suite Teardown    Close All Sessions
    
*** Keywords ***
# Pythonでのみ定義が難しい場合や、
# Pythonで定義されたKeywordを組み合わせた処理を使いたい場合、
# Robotファイル内にKeywordを定義する
Check Interface Status
    [Arguments]    ${interface}    ${expected_status}
    Log    Checking interface ${interface} expected status: ${expected_status}
    Should Be True    '${expected_status}' == 'up' or '${expected_status}' == 'down'

Check Packet Success Rate
    [Arguments]    ${interface}    ${expected_rate}
    ${rate}=    Set Variable    ${expected_rate}
    Log    Packet success rate for ${interface}: ${rate}%
    Should Be True    ${rate} >= 99.99

*** Variables ***
# テストで使う変数を定義する
${TARGET_DEVICE}    device-01
${TARGET_INTERFACE}    Ethernet1/1
${EXPECTED_STATUS}    up
${EXPECTED_PACKET_SUCCESS_RATE}    99.99

*** Test Cases ***
# TestCaseの工程がわかるように、処理をKeyword単位で分割して使う
Validate Device Status
    Log    Start validation for ${TARGET_DEVICE}
    Check Interface Status    ${TARGET_INTERFACE}    ${EXPECTED_STATUS}
    Check Packet Success Rate    ${TARGET_INTERFACE}    ${EXPECTED_PACKET_SUCCESS_RATE}
    Log    Validation for ${TARGET_DEVICE} completed successfully
