---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Template Index

この領域には、再利用する記録テンプレートを格納する。

## 保存例

- `knowledge_template.md` — Knowledge / Knowledge_at の共通テンプレート
- `python_template.md` — Python 実装の雛形
- `robot_template.robot` — Robot Framework のシナリオテンプレート
- `incident_template.md` — インシデント記録の雛形

## 運用ルール

- 新規記録を作るときは、まずテンプレートを利用する
- `Metadata` には `Tags` / `Related Keywords` / `Referenced Sources` を必ず記載する
- 生成されるファイルには、作成時に参照した資料・コマンド・ログ・手順書を `## 参照元` または `## Reference` として残す
- 参照元は次の 2 種類を分けて記載する
  - 参照元（外部/OKF外）: OKF の外側にある資料、URL、公開ドキュメント、ログ、計測結果、手順書など
  - 参照元（OKF 内）: README、docs、template、knowledge、knowledge_at、device_docs、memory、既存の記録など、この OKF 内で根拠としたファイル
- OKF 内の任意のファイルは参照元になり得る。README・docs・template・knowledge・knowledge_at・device_docs・memory のどれでも、根拠として使った場合は記載する
- `Related Records` には `Related From` / `Related To` / `Relationship` を明記する
- タグや keyword は小文字の `snake_case` に揃える
- 関係語は `generalized_to`, `derived_from`, `supports`, `validates` を基本とする
- 似た記録が増えないよう、テンプレートに沿って再利用する
- 参照元の記載が不足しているファイルは未完成扱いとし、再確認を行う

## Metadata 例

```markdown
## Metadata
- Tags: interface, validation, link_status
- Related Keywords: show_interfaces_status, interface_up_down, port_state
- Referenced Sources: docs/DEVELOPMENT_GUIDE.md, device_docs/cisco/iosxe_command_reference.md, show interfaces status
```
