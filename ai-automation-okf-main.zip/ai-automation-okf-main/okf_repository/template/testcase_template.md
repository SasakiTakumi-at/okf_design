---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# 検証記録テンプレート

---
type: validation
target_function: 
name: 
executed_at: 
owner: 
---

# 検証記録

## 基本情報
- 種別: validation
- 対象機能:
- 試験名:
- 実施日:
- 実施者:

## 検証目的
- 

## 検証観点
- 

## 確認項目
- 項目名:
- 確認内容:
- 期待値:
- 実測値:

## 検証結果
- 判定: 正常 / 異常 / 要再確認
- 結果概要:
- 根拠:

## 関連情報
- 関連手順:
- 関連インシデント:
- 関連テスト:
- 備考:

## 参照元
- 参照資料:
- 参照元（外部/OKF外）: OKF リポジトリの外側にある資料・URL・ログ・手順書・計測結果など
- 参照元（OKF 内）: README、docs、template、knowledge、knowledge_at、device_docs、memory、既存の記録など、この OKF 内で根拠にしたファイル
- 参照コマンド:
- 参照ログ:
- 補足:

> NOTE: 参照元（外部/OKF外）は OKF の外部情報源、参照元（OKF 内）はこのリポジトリ内の既存ファイルを指す。両方を使う場合は分けて記載する。

