---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

---
type: knowledge
category: workflow
target_function: udp_communication, packet_loss, bandwidth_threshold
name: udp_packet_loss_threshold_search_workflow
---

# UDP帯域閾値探索ワークフロー

## 概要
- パケットロス発生時の帯域変更試験では、ロス発生帯域とロスなし帯域を二分探索で絞り込む
- 判定基準は `パケットロス率が 5% 未満であること`
- 試験は上限値と下限値の差分が 10 Mbps 以下になった時点で終了する

## Metadata
- Tags: udp, packet_loss, bandwidth_threshold, workflow, validation
- Related Keywords: iperf, packet_loss_rate, binary_search, threshold_search, udp_communication
- Referenced Sources: docs/DEVELOPMENT_GUIDE.md, okf_repository/knowledge_at/INDEX.md, okf_repository/knowledge_at/testcases/README.md, okf_repository/template/testcase_template.md

## 参照元
- 参照資料: シナリオ自動生成テスト手順書, docs/DEVELOPMENT_GUIDE.md
- 参照したドキュメント/URL/パス: OKF 内のテンプレート, knowledge_at の記録方針, testcases の正式扱い
- OKF 内の参照元ファイル: okf_repository/knowledge/INDEX.md, okf_repository/knowledge_at/INDEX.md, okf_repository/knowledge_at/testcases/README.md, okf_repository/template/testcase_template.md
- 参照コマンド: show running-config, clear counters GigabitEthernet0/4, show interface GigabitEthernet0/4, show process cpu, show process resources, iperf
- 参照ログ: iperf 実行結果, interface log
- 補足: 一般化の対象として、ユースケースごとの差分を小さく保ち、閾値探索の手順そのものを再利用する

## 前提条件
- Janog58 デモ構成で UDP 通信が可能な環境であること
- `iperf` サーバとクライアントが接続済みであること
- 対象リンクの基準値として `show interface GigabitEthernet0/4` で通常状態を確認済みであること

## 試験手順
1. パケットロスが発生した帯域を初期値として扱う
2. ロス発生有無に応じて二分探索を用いて帯域を調整する
3. ロス発生帯域を上限値、ロスなし帯域を下限値として記録する
4. 上限値と下限値の中間値を用いて試験を実施する
5. 上限値と下限値の差が 10 Mbps 以下になるまで繰り返す
6. ロス発生閾値を記録する

## 実施時の確認項目
- `show running-config` を取得して現行設定を把握する
- `clear counters GigabitEthernet0/4` を実行して、測定前后の差分を明確にする
- `show process cpu` と `show process resources` を定期取得する
- `show interface GigabitEthernet0/4` を実行前後で比較する
- `Lost/Total` からパケットロス率を算出する
- `output packets` が増加していることを確認する

## 判定ルール
- パケットロス率が 5% 未満の場合: 合格
- パケットロス率が 5% 以上の場合: 不合格
- `output packets` の増加がない場合: 判定の再確認が必要

## 典型的な結果
- 成功: 305 Mbps でロス率 4.2% となり合格
- 失敗: 310 Mbps でロス率 6.4% となり不合格

## 注意事項
- すべての探索値は実測値をもとに更新する
- 推測や憶測で閾値を決めない
- ロスが発生した帯域とロスなし帯域を分けて記録する
- 重要な判定は `実測値`, `判定基準`, `比較結果` の三点を揃えて残す
