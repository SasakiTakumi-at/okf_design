---
## LLM 利用ポリシー（読み取りのみ許可／編集禁止）

LLM にはこのリポジトリの本文を編集させず、読み取りのみを許可します。
なお、対象リポジトリは Git 管理下でクローンされた別リポジトリとして扱い、作業ディレクトリの絶対パスではなくリポジトリ名で記載します。


編集禁止対象:
 - ai-automation_pf_harness
 - ai-automation_test_docs
 - ai-automation-platform

例外:
 - ai-automation-platform/src/user/generated
   - ここでは作成、修正、削除を許可する。
   - これはテストシナリオと切り分けシナリオの生成場所であるため。
---

# Knowledge Index

この領域には、再利用可能な一般化知識を保存する。

## 目的

- 検証に使える汎用手順を残す
- 一般化した判断基準を整理する
- 再利用可能な知見として抽出する
- 実運用と検証の標準化を支える

## 保存先の例

- `workflows/INDEX.md`
- `workflows/01-01-01_udp_packet_loss_threshold_workflow.md`
- `references/INDEX.md`
- `references/01-01-01_device_cli_reference.md`
- `decisions/INDEX.md`
- `decisions/01-01-01_interface_failure_decision.md`
- `experiments/INDEX.md`
- `experiments/01-01-01_udp_loss_threshold_experiment.md`

## 運用ルール

- 現在の状況に依存しない内容をここに保存する
- その場限りの情報は Knowledge へ落とさない
- 再利用価値がある情報のみを一般化する
- 事例や実測値から汎用原則を抽出する
- 分類ごとに以下のカテゴリを使い分ける
  - `workflows/`: 再利用可能な手順フロー
  - `references/`: コマンド・設定例・参照資料
  - `decisions/`: 判定基準と意思決定ルール
  - `experiments/`: 実験結果と再利用可能な知見
- 各記録に `Tags` / `Related Keywords` / `Referenced Sources` を付けて、類似知識や関連シナリオへ辿れるようにする
- `Referenced Sources` には、知識を作成する際に参照した資料・CLI・ログ・既存記録を記載する
- OKF 内の任意のファイルも参照元となり得る。Knowledge だけでなく、template、device_docs、knowledge_at、docs、README なども根拠として利用された場合は記載する
- タグと関連 keyword は小文字の `snake_case` に統一する

## Metadata の例

```markdown
## Metadata
- Tags: interface, recovery, validation
- Related Keywords: interface_down, show_interface_status, triage_test
- Referenced Sources: docs/DEVELOPMENT_GUIDE.md, okf_repository/device_docs/cisco/iosxe_command_reference.md, show interfaces status
```
