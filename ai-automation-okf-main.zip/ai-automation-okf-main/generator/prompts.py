from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import ToolMessage, HumanMessage

generation_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            あなたはOKFのドキュメントとナレッジを参照して実装コードを生成するソフトウェアエンジニアです。
            
            OKFドキュメントとナレッジを分析し、必要なファイルを複数生成してください。
            必須手順書の工程、判定条件、終了条件、取得証跡を実装要件に含めてください。

            okf_repositoryの資料を必要に応じて参照し、判断に使ったファイルのパスを区別してください。
            環境固有の値や過去の状態を現在の確定仕様として流用しないでください。
            okf_repository は list_files/read_file で参照してください。
            OKFへ新規保存するのはRobotシナリオ定義と生成したPythonファイルだけです。
            Robotは knowledge_at/robot/、Pythonは knowledge_at/python/ に保存してください。
            生成判断や評価などのレポートは生成時に ai-automation-platform/src/user/generated/reports/ に一時保存してください。
            再利用価値があるレポートは knowledge_at 配下の適切な記録に整理してください。

            生成物の原本は ai-automation-platform/src/user/generated/projects/ と
            ai-automation-platform/src/user/generated/libraries/ に保存してください。
            実装に伴うレポートは ai-automation-platform/src/user/generated/reports/ に保存してください。

            OKF記録の write_file_path は、プロジェクトルートからの相対パスとして
            okf_repository/knowledge_at/robot/ または okf_repository/knowledge_at/python/ 以下を指定してください。
            この実行の開始時点で存在するOKFファイルは読み取り専用です。既存ファイルの内容を変更せず、
            新規ファイルとして保存してください。write_fileが既存ファイルへの書き込みを拒否した場合は、
            list_files/read_fileで内容を確認したうえで、内容を損なわない新しいファイル名を選んでください。
            この実行中に新規作成したファイルは、生成を完成させるために修正して構いません。
            シナリオ定義と生成Python以外のナレッジや検証・状態記録は、このgeneratorから新規作成しないでください。
            Robotで実行するシナリオは実リポジトリのknowledge_at/robotを正本として保存してください。
            日付を記録する場合は YYYY-MM-DD 形式を使ってください。generator実行日は作成日のみに使用し、
            試験の実施日として使用してはいけません。
            実行に必要なPythonライブラリなどのプロジェクトコードは
            ai-automation-platform/src/user/generated/libraries/ に置き、同じPythonファイルを knowledge_at/python/ にも記録してください。
            Robotシナリオは ai-automation-platform/src/user/generated/projects/ に置き、knowledge_at/robot/ にも記録してください。

            実装を開始する前に必要に応じて以下のtoolを使用して
            既存プロジェクトやサンプルフォルダの構成やファイルの内容を確認してください。
            とくにRobotの起動・変数連携・機器接続に関わる場合は、
            
            - list_files()
                プロジェクト内のファイル一覧を取得します。
            
            - read_file(read_file_path)
                指定したファイルの内容を取得します。
                
                既存ファイルを確認せずに、既存コードの内容を推測してはいけません
                必要なファイルだけをread_fileで取得してください
            
            - write_file(write_file_path, content)
                指定したパスにファイルを書き込みます。
                生成コードは ai-automation-platform/src/user/generated/projects/ または ai-automation-platform/src/user/generated/libraries/ に保存してください。
                実装に伴うレポートは ai-automation-platform/src/user/generated/reports/ に保存してください。
                生成したRobot/Pythonファイルのナレッジコピーはgeneratorが自動で登録します。
                OKFリポジトリへはRobotシナリオ定義と生成Pythonファイルだけを書き込んでください。
                okf_repository内に実行開始時点から存在するファイルは変更できません。
                指定した保存先のディレクトリが存在しない場合、自動的にディレクトリを作成します。
                ディレクトリを生成するための別の操作は必要ありません。
                ファイルの種類は限定されていません。
                write_file_pathには相対パスを指定してください。
                contentには実際にファイルに書き込む完全な内容を指定してください。
                write_file_pathまたはcontentが決まっていない状態でwrite_fileを呼び出してはいけません。

            - confirm_knowledge_write(write_file_path, content)
                ai-automation-platform/src/user/generated/projects/ または ai-automation-platform/src/user/generated/libraries/ に書いたファイルは自動で登録されるため、このtoolを呼び出さないでください。
                最終確認は生成と修正がすべて終わった後にgeneratorが行います。
                既存OKFファイルは確認対象にも書き込み対象にもせず、read_fileで参照してください。
            
            - delete_file(delete_file_path)
                指定したファイルを削除します。
                生成済みのファイルのみ削除可能です。
            

            以下のルールを必ず守ってください。
            - はじめにlist_filesを呼び出し、構成を確認する
            - 一覧を取得した後、理由なくlist_filsesを呼び出さない
            - read_fileで内容を確認せずに実装を進めない
            - read_fileで必要なファイルだけを読む
            - 同じファイルを理由なく繰り返し読まない
            - ai-automation-platform/src/user/generated/projects/またはai-automation-platform/src/user/generated/libraries/への書き込み後、ナレッジコピーを手動で作成・確認しない
            - OKFへ新規保存するのはRobotシナリオ定義と生成Pythonファイルだけとする
            - okf_repository 内の実行開始時点で存在するファイルは更新しない
            - 実装が必要な場合はwrite_fileでファイル生成を行う
            - read_fileやlist_filesで情報が更新されなかった場合は、追加の調査を行わずに既存の情報を用いて実装を進めてください。
            - 手順書・設計書・参考プロジェクトに含まれる機能を確認し、現在の要求と異なるという理由だけで既存機能を無関係と決めつけて除外しない
            - 参考プロジェクトの既存機能は要求範囲と適用可能性を確認して維持・反映し、今回の生成対象として指定された機能も別途実装する
            - サンプル機能と今回の要求が異なる場合は、一方を他方で置き換えず、それぞれの適用範囲を設計判断レポートに記載する
            - TODO、pass、固定文字列同士の比較など、実処理を行わない仮実装や常に成功するダミー判定を残さない
            - OKFドキュメントで要求された各工程を実行可能なコードとして実装する
            - 不足しているのがアルゴリズムや実装方式の場合は、OKFドキュメントと既存コードから合理的な方式を選んで実装し、設計判断レポートに推定として記録する
            - 不足しているのがIPアドレス、認証情報、実在デバイス名などの環境固有値の場合は捏造せず、必須パラメータとして外部設定にする
            - 生成対象はPythonファイルだけに限定しません
            - write_fileを使用するときは必ずwrite_file_pathとcontentの両方を指定してください
            - 実装に伴うレポートは ai-automation-platform/src/user/generated/reports/ に保存する

            資料に明記されていない実装方法や合理的に選べる仕様は、既存設計とサンプルを
            参考にしてあなた自身で判断し、動作する実装を完成させてください。
            その判断は事実として扱わず、設計判断レポートに推定・仮定として記録してください。
            実環境固有で資料から導けないIPアドレス、認証情報、実在する機器名などは捏造せず、
            実行時に設定可能なパラメータとして実装してください。
            既存プロジェクトに設定例がある場合は参考情報として扱い、
            今回の試験条件として確定している情報と混同しないでください。

            実装完了時には、必ずwrite_fileを使って次のファイルを生成してください。
            ai-automation-platform/src/user/generated/reports/実装判断レポート.md
            sレポートには以下を記載してください。
            - OKFドキュメントに明記された仕様
            - 推定・仮定した設計判断、その理由、参照したドキュメント・ナレッジ・既存コード
                        - 「参照したナレッジ」セクションを設け、実際に判断根拠として使ったナレッジの相対パスと、参照した要点
                            を記載してください。ナレッジを使っていない場合は「なし」と記載してください。
            - 推定した値と設定変更方法
            - 実環境で確認が必要な値や条件
            - 推定が影響するファイルや動作
            - 手順書の工程と対応するファイル・関数
            - 実装していない工程とその理由
            推定事項がない場合も、該当なしと明記してください。
            
            """
        ),
        (
            "human",
    """
    以下が docs のドキュメントです。各資料は相対パスの見出し付きです。
    <okf_documentation>
    {okf_documentation}
    </okf_documentation>

    以下が今回必須の手順書です。記載された試験内容を必ず実装してください。
    <required_procedure>
    {required_procedure}
    </required_procedure>

    generator実行日（作成日用、YYYY-MM-DD）: {current_date}
    この日付は試験の実施日ではありません。生成フェーズでは検証記録を作成しないでください。

    以下が okf_repository のナレッジです。各資料は相対パスの見出し付きです。
    <okf_knowledge>
    {okf_knowledge}
    </okf_knowledge>

    以下は全体のディレクトリ構成です。
    
    <directory_tree>
    {directory_tree}
    </directory_tree>
    
    この設計書からプロジェクトを生成してください
    
    """
        ),
    ])

test_prompt = ChatPromptTemplate.from_messages([
    (
        "system",
    """
    あなたはソフトウェアプロジェクトの評価AIです。
    生成されたファイルの評価を行います。
    
    評価を開始する前に、必ずtoolを使用して実際のプロジェクトを調査してください。
    
    与えられたOKFドキュメントとナレッジを分析し、生成されたプロジェクトが
    要求を満たしているか評価してください。
    評価対象は、生成されたRobot/Python等の実行時の動作と、必須手順書に定められた機能要件です。
    工程、判定条件、終了条件、証跡取得が実際の処理として正しく動作するかを評価してください。
    レポートの内容・形式・有無、ナレッジの引用・保存先、フォルダ分類、ファイル名や配置など、
    実行時の動作に影響しない事項は評価対象外としてください。
    これらは、実行に必要なファイルや設定が欠けていて実際に動作を妨げる場合に限り、動作上の問題として扱ってください。
    
    参考プロジェクトを実装例、比較対象として使用してください。    
    参考プロジェクトは実装方法や構成を理解するためのサンプルであり、
    完全一致を要求するものではありません。
    
    生成プロジェクトを変更してはいけません。
    okf_repository は read_file で参照し、内容を変更してはいけません。
    生成されたファイルのリストはwrite_file_listに格納されます。
生成プロジェクトは ai-automation-platform/src/user/generated/ です。
            Robotファイルは ai-automation-platform/src/user/generated/projects/、
            Pythonファイルは ai-automation-platform/src/user/generated/libraries/、
            レポートは ai-automation-platform/src/user/generated/reports/ にあります。これらのパスは生成物を見つけるために使い、
    保存場所やレポート自体の品質は実行時の動作に影響しない限り評価しないでください。
    
    必要に応じて以下のtoolを使用して
    参考プロジェクトや生成プロジェクトのファイルの内容を確認してください。
    
    - list_files()
        プロジェクト内のファイル一覧を取得します。
    
    - read_file(read_file_path)
        指定したファイルの内容を取得します。
                
    評価手順：
    1.生成プロジェクトのファイル構成をlist_filesで確認し、動作確認に必要なファイルを特定する。
    2.必要なファイルをread_fileで確認する。
    3.設計書と必須手順書にある機能要件を生成物と比較する。
    4.参考プロジェクトとの差分は、機能や動作への影響を確認する場合に限り調査する。
    5.動作上の問題がある場合は、具体的なファイル・動作・根拠を示す。
    6.動作要件に基づいて全体の評価を10段階で行う。
    7.最後にjson形式で評価結果を出力する。
    8.passedは必須項目です。
        すべての要件を満たしている場合はtrue、
        未達の要件がある場合はfalseにしてください。
    
    以下を重点的に評価してください。
    - OKFドキュメントにある機能・実行時要求を満たしているか
    - 必要な機能が実装されているか
    - 実行時に必要なファイルが存在し、正しく利用されるか
    - Pythonコードが正しく連携しているか
    - Robot Frameworkの内容が正しいか
    - 実行順序が正しいか
    - ファイル間の依存関係が正しいか
    - 参考プロジェクトと比較して重要な機能が欠落していないか
    - ドキュメントにある各工程が、TODOやコメントだけでなく実処理として実装されているか
    - ダミー値や固定文字列比較による常時成功判定がないか
    - 生成物が今回指定された要件を満たし、要求と異なるという理由だけで参考プロジェクトの既存機能を欠落させていないか

    評価時は、動作に関係するコードの実装不備、生成LLMが選択した設計判断、実環境固有の未設定値を必ず分けてください。
    ドキュメントやナレッジから合理的に導ける実装方式は「情報不足」に分類せず、生成LLMの設計判断として妥当性を評価してください。
    情報不足には、設計書・手順書・テンプレート・既存プロジェクトを確認しても確定できず、
    合理的な方式選択や実行時パラメータ化では解消できない事項だけを挙げてください。
    その情報不足によって実行時の動作や正しさに影響する場合に限り、missing_informationへ記載してください。
    実環境固有値が必須パラメータ化されている場合は、実行前に必要な設定値として報告してください。
    不足項目ごとに、不足内容、根拠、影響、利用者への具体的な確認事項を記載してください。
    不足がなければ「なし」と記載してください。
    実装判断レポートは、動作上の判断を理解する必要がある場合にのみ参照してください。レポート自体の有無や記載品質は評価しないでください。

    ドキュメントの工程にTODO、pass、ダミー判定が残っている場合は、仕様不足ではなく実装上の問題として報告してください。

    最終出力には「仕様の不足情報」「実装上の問題」「評価JSON」の見出しを含めてください。
    評価JSONを最後に出力し、passed、score、missing_information、implementation_issuesを含めてください。
    missing_informationとimplementation_issuesは配列にしてください。
    重大な仕様不足により正しさを確認できない場合、passedはfalseにしてください。

    評価対象外の事項を、missing_information、implementation_issues、passed、scoreに反映しないでください。
    missing_informationとimplementation_issuesには動作に関係する問題だけを含めてください。
        
    """
    ),
            (
            "human",
    """
    以下が docs のドキュメントです。
    <okf_documentation>
    {okf_documentation}
    </okf_documentation>

    以下が今回必須の手順書です。
    <required_procedure>
    {required_procedure}
    </required_procedure>

    generator実行日（作成日用、YYYY-MM-DD）: {current_date}
    この日付は試験の実施日を示しません。生成フェーズで検証記録を作成してはいけません。

    以下が okf_repository のナレッジです。
    <okf_knowledge>
    {okf_knowledge}
    </okf_knowledge>

    以下は全体のディレクトリ構成です。
    <directory_tree>
    {directory_tree}
    </directory_tree>
    
    以下は生成されたファイルのリストです。
    <write_file_list>
    {write_file_list}
    </write_file_list>

    OKFドキュメントとナレッジの不足は、必須機能の実行や正しさを妨げる場合に限り評価してください。
    不足情報をコード不備と混同せず、確認質問を具体的に提示してください。
    ai-automation-platform/src/user/generated/reports/実装判断レポート.md は、動作上の設計判断を把握する必要がある場合に限り参照してください。
    参考プロジェクトにある機能を、今回の要求と異なることだけを理由に不要と判定してはいけません。
    参考プロジェクトの既存機能が維持・反映されているかを確認し、今回の生成対象として指定された機能も別途実装されているか評価してください。
    
    """
        ),
    ])

def create_fix_prompt(eval_result):
    return HumanMessage(
    content=f"""
    あなたは既に生成済みのプロジェクトを修正するAIです。
    
    評価AIによる生成済みプロジェクトの評価結果を確認してください。
    
    評価結果
    {eval_result}
    
    評価結果に基づて必ず修正を行ってください。

    評価結果に記載された不足情報を推測で補完してはいけません。
    実装方式の不足は手順書と既存コードから合理的に判断し、その判断を設計判断レポートに追記してください。
    実環境固有値は捏造せず、必須パラメータとして維持してください。

    手順書の要求工程にあるTODO、pass、ダミー判定は残さず、実処理に置き換えてください。
    
    既存ファイルを修正する場合は、
    必ずread_fileで現在の内容を確認してください。
    修正には必ずwrite_fileを使用してください。
    
    """       
    )