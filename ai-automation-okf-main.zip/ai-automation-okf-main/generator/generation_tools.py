"""生成・評価LLMに公開する、プロジェクト内ファイル操作ツール。"""

from pathlib import Path
import hashlib
from langchain_core.tools import tool

class GenerationTools:
    """指定したプロジェクトルート内に操作範囲を限定してtoolを提供する。"""
    
    def __init__(self, base_dir: str | Path):
        """操作対象を固定し、実行開始時点のOKFファイルを保護する。"""
        self.base_dir = Path(base_dir).resolve()
        self.generated_files: set[str] = set()
        self.approved_knowledge_writes: dict[str, str] = {}
        self.pending_knowledge_writes: dict[str, str] = {}
        self.generated_knowledge_paths: dict[str, str] = {}
        self.okf_repository_root = (self.base_dir / "okf_repository").resolve()
        self.protected_okf_files = (
            {
                path.resolve()
                for path in self.okf_repository_root.rglob("*")
                if path.is_file()
            }
            if self.okf_repository_root.exists()
            else set()
        )
    
    def _read_file(self, read_file_path: str) -> str:
        """相対パスで指定された既存ファイルをUTF-8で読み込む。"""
        try:
            file_path = (self.base_dir / read_file_path).resolve()
            if not file_path.is_relative_to(self.base_dir):
                return "Error: project directory outside access is not allowed."

            relative_path = file_path.relative_to(self.base_dir).as_posix()
            if relative_path in self.pending_knowledge_writes:
                return self.pending_knowledge_writes[relative_path]
            if not file_path.exists():
                return f"Error: file not found: {read_file_path}"
            if not file_path.is_file():
                return f"Error: not a file: {read_file_path}"
            
            return file_path.read_text(encoding='utf-8')

        except Exception as e:
            return f"Error: failed to read file: {e}"
        
    def _list_files(self) -> str:
        """内部管理用ディレクトリを除く、プロジェクト内のファイル一覧を返す。"""
        files = set()
        for path in self.base_dir.rglob("*"):
            if not path.is_file():
                continue
            
            if any(part in {".git", "__pycache__",".venv"} for part in path.parts):
                continue
            
            files.add(path.relative_to(self.base_dir).as_posix())
            
        files.update(self.pending_knowledge_writes)
        return '\n'.join(sorted(files))

    def _stage_generated_knowledge(self, relative_path: str, content: str) -> str | None:
        """Robot/Python生成物を対応するOKF領域へ最終確認用に登録する。"""
        source_path = Path(relative_path)
        if len(source_path.parts) < 3 or source_path.parts[0] != "generated":
            return None

        if source_path.parts[1] == "robot" and source_path.suffix.lower() == ".robot":
            knowledge_root = self.okf_repository_root / "knowledge_at" / "robot"
        elif source_path.parts[1] == "python" and source_path.suffix.lower() == ".py":
            knowledge_root = self.okf_repository_root / "knowledge_at" / "python"
        else:
            return None

        mapped_path = self.generated_knowledge_paths.get(relative_path)
        if mapped_path is not None:
            self.pending_knowledge_writes[mapped_path] = content
            return mapped_path

        knowledge_relative_path = Path(
            knowledge_root.relative_to(self.base_dir), *source_path.parts[2:]
        ).as_posix()
        candidate_path = self.base_dir / knowledge_relative_path
        if candidate_path.exists():
            if candidate_path.is_file():
                try:
                    if candidate_path.read_text(encoding="utf-8") == content:
                        return None
                except OSError:
                    pass

            suffix = candidate_path.suffix
            stem = candidate_path.stem
            version = 1
            while candidate_path.exists() or knowledge_relative_path in self.pending_knowledge_writes:
                version += 1
                version_suffix = "_generated" if version == 2 else f"_generated_{version - 1}"
                candidate_path = candidate_path.with_name(f"{stem}{version_suffix}{suffix}")
                knowledge_relative_path = candidate_path.relative_to(self.base_dir).as_posix()

                if candidate_path.is_file():
                    try:
                        if candidate_path.read_text(encoding="utf-8") == content:
                            return None
                    except OSError:
                        pass

        self.generated_knowledge_paths[relative_path] = knowledge_relative_path
        self.pending_knowledge_writes[knowledge_relative_path] = content
        self.generated_files.add(knowledge_relative_path)
        return knowledge_relative_path

    def _write_file(self, write_file_path: str, content: str) -> str:
        """ルート外への書き込みを拒否し、親ディレクトリを作成して保存する。"""
        try:        
            file_path = (self.base_dir / write_file_path).resolve()
            # '..'やシンボリックリンクによるプロジェクト外への書き込みを防ぐ。
            if not file_path.is_relative_to(self.base_dir):
                return "Error: project directory outside access is not allowed."

            relative_path = file_path.relative_to(self.base_dir).as_posix()
            is_okf_file = file_path.is_relative_to(self.okf_repository_root)
            content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
            if is_okf_file and relative_path not in self.generated_files:
                if file_path in self.protected_okf_files or file_path.exists():
                    return (
                        f"Error: existing OKF file is read-only: {write_file_path}. "
                        "Choose a new file path instead."
                    )
            if is_okf_file and self.approved_knowledge_writes.get(relative_path) != content_hash:
                return (
                    f"Error: user confirmation is required before writing OKF file: {write_file_path}. "
                    "Call confirm_knowledge_write with the exact path and content first."
                )

            if is_okf_file:
                self.pending_knowledge_writes[relative_path] = content
                self.generated_files.add(relative_path)
                return f"Staged OKF write for final confirmation: {write_file_path}"
        
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            # 削除できるのは、このtoolインスタンスが生成したファイルだけ。
            self.generated_files.add(relative_path)
            knowledge_path = self._stage_generated_knowledge(relative_path, content)
            
            if knowledge_path is not None:
                return (
                    f"Successfully wrote: {write_file_path} "
                    f"(knowledge copy queued: {knowledge_path})"
                )
            return f"Successfully wrote: {write_file_path}"
        
        except Exception as e:
            return f"Error: failed to write fil: {e}"

    def _confirm_knowledge_write(self, write_file_path: str, content: str) -> str:
        """OKFへの新規出力を保留し、生成完了後の確認用に登録する。"""
        file_path = (self.base_dir / write_file_path).resolve()
        if not file_path.is_relative_to(self.base_dir):
            return "Error: project directory outside access is not allowed."
        if not file_path.is_relative_to(self.okf_repository_root):
            return "Error: confirmation is only available for the OKF repository."

        relative_path = file_path.relative_to(self.base_dir).as_posix()
        if file_path in self.protected_okf_files or (
            file_path.exists() and relative_path not in self.generated_files
        ):
            return f"Error: existing OKF file is read-only: {write_file_path}."
        validation_root = self.okf_repository_root / "knowledge_at" / "testcases"
        is_validation_record = (
            file_path.is_relative_to(validation_root)
            and "type: validation" in content.lower()
        )

        if is_validation_record:
            return (
                "Error: this generator creates test files but does not execute them. "
                "Create validation records only in the separate post-execution evidence workflow."
            )

        allowed_roots = (
            self.okf_repository_root / "knowledge_at" / "robot",
            self.okf_repository_root / "knowledge_at" / "python",
        )
        if not any(file_path.is_relative_to(root) for root in allowed_roots):
            return "Error: only Robot and Python knowledge files may be written."

        content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        self.approved_knowledge_writes[relative_path] = content_hash
        return f"Queued for final confirmation: {relative_path}"

    def commit_knowledge_writes(self) -> list[str]:
        """保留中の各ナレッジを最終内容で一度確認し、承認分だけ新規保存する。"""
        written_paths = []
        for relative_path, content in list(self.pending_knowledge_writes.items()):
            file_path = (self.base_dir / relative_path).resolve()
            if (
                not file_path.is_relative_to(self.okf_repository_root)
                or file_path in self.protected_okf_files
                or file_path.exists()
            ):
                print(f"Error: existing or invalid OKF destination: {relative_path}")
                self.pending_knowledge_writes.pop(relative_path, None)
                self.approved_knowledge_writes.pop(relative_path, None)
                self.generated_files.discard(relative_path)
                continue

            print(f"\nOKFファイル出力の最終確認: {relative_path}\n--- 提案内容 ---\n{content}\n---")
            while True:
                try:
                    answer = input("この内容で新規出力しますか？ [yes/no]: ").strip().lower()
                except EOFError:
                    print(f"Error: interactive confirmation unavailable: {relative_path}")
                    self.pending_knowledge_writes.pop(relative_path, None)
                    self.approved_knowledge_writes.pop(relative_path, None)
                    self.generated_files.discard(relative_path)
                    break

                if answer in {"yes", "y", "はい"}:
                    try:
                        file_path.parent.mkdir(parents=True, exist_ok=True)
                        with file_path.open("x", encoding="utf-8") as output_file:
                            output_file.write(content)
                    except Exception as error:
                        print(f"Error: failed to write OKF file {relative_path}: {error}")
                        self.generated_files.discard(relative_path)
                    else:
                        written_paths.append(relative_path)
                    self.pending_knowledge_writes.pop(relative_path, None)
                    self.approved_knowledge_writes.pop(relative_path, None)
                    break

                if answer in {"no", "n", "いいえ"}:
                    self.pending_knowledge_writes.pop(relative_path, None)
                    self.approved_knowledge_writes.pop(relative_path, None)
                    self.generated_files.discard(relative_path)
                    print(f"Cancelled OKF write: {relative_path}")
                    break

                print("yes または no で回答してください。")

        return written_paths
    
    def _delete_file(self, delete_file_path: str) -> str:
        """この実行で生成したプロジェクト内ファイルだけを削除する。"""
        file_path = (self.base_dir / delete_file_path).resolve()
        if not file_path.is_relative_to(self.base_dir):
            return "Error: project directory outside access is not allowed."

        relative_path = file_path.relative_to(self.base_dir).as_posix()
        if relative_path in self.pending_knowledge_writes:
            self.pending_knowledge_writes.pop(relative_path, None)
            self.approved_knowledge_writes.pop(relative_path, None)
            self.generated_files.discard(relative_path)
            for source_path, knowledge_path in list(self.generated_knowledge_paths.items()):
                if knowledge_path == relative_path:
                    self.generated_knowledge_paths.pop(source_path, None)
            return f"Successfully discarded pending write: {delete_file_path}"

        if relative_path not in self.generated_files:
            return f"Error: file not previously generated: {delete_file_path}"
                
        try:
            if not file_path.is_relative_to(self.base_dir):
                return "Error: project directory outside access is not allowed."

            if not file_path.exists():
                return f"Error: file not found: {delete_file_path}"

            if not file_path.is_file():
                return f"Error: not a file: {delete_file_path}"

            file_path.unlink()
            self.generated_files.discard(file_path.relative_to(self.base_dir).as_posix())
            knowledge_path = self.generated_knowledge_paths.pop(relative_path, None)
            if knowledge_path is not None:
                self.pending_knowledge_writes.pop(knowledge_path, None)
                self.generated_files.discard(knowledge_path)

            return f"Successfully deleted: {delete_file_path}"

        except Exception as e:
            return f"Error: failed to delete file: {e}"
    
    def get_generation_tools(self):
        """生成LLM用に一覧・読込・書込・生成物削除のtoolを返す。"""
        @tool
        def list_files() -> str:
            """プロジェクト内のファイルを一覧取得する"""
            return self._list_files()
        
        @tool
        def read_file(read_file_path: str) -> str:
            """ 
            指定されたパスのファイルを読み込む
            Args:
                path (str): プロジェクトルートからの相対パス
            """            
            return self._read_file(read_file_path)
        
        @tool
        def write_file(write_file_path: str, content: str) -> str:
            """プロジェクト内にファイルを書き込む。既存のOKFファイルは更新できない。
            Args:
                write_file_path: 
                    プロジェクトルートからの相対パス
                content: 
                    ファイルに書き込む完全な内容
            """
            return self._write_file(write_file_path, content)

        @tool
        def confirm_knowledge_write(write_file_path: str, content: str) -> str:
            """OKFナレッジへの新規出力案を登録し、生成完了後に最終確認する。"""
            return self._confirm_knowledge_write(write_file_path, content)
        
        @tool
        def delete_file(delete_file_path: str) -> str:
            """プロジェクト内のファイルを削除する。
            Args:
                delete_file_path: 
                    プロジェクトルートからの相対パス
            """
            return self._delete_file(delete_file_path)
        
        return [
            list_files,
            read_file,
            confirm_knowledge_write,
            write_file,
            delete_file
        ]
    
    def get_evaluation_tools(self):
        """評価LLMには、調査に必要な一覧・読込toolだけを返す。"""
        @tool
        def list_files() -> str:
            """プロジェクト内のファイルを一覧取得する"""
            return self._list_files()
        
        @tool
        def read_file(read_file_path: str) -> str:
            """ 
            指定されたパスのファイルを読み込む
            Args:
                read_file_path (str): プロジェクトルートからの相対パス
            """            
            return self._read_file(read_file_path)
                
        return [
            list_files,
            read_file,
        ]