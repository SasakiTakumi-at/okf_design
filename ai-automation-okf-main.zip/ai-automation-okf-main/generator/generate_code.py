"""設計資料からテストプロジェクトを生成し、評価・修正する実行スクリプト。"""

from pathlib import Path
from dataclasses import dataclass
from datetime import date
from typing import Any

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, ToolMessage
import httpx
from collections import Counter

from generation_tools import GenerationTools
from prompts import (
    generation_prompt, test_prompt, create_fix_prompt
)


@dataclass
class RuntimeContext:
    """main()で初期化した資料、LLM、toolを補助関数へ渡す実行コンテキスト。"""

    documentation: str
    knowledge: str
    knowledge_paths: list[str]
    project_root: Path
    generation_decision_path: str
    llm_with_tools: Any
    generate_llm: Any
    generation_tool_map: dict
    test_llm_with_tools: Any
    evaluation_tool_map: dict
    generation_decision_reports: list[str]

def get_directory_tree(root: str) -> str:
    """モデルに既存構成を伝えるため、除外対象を除いたツリーを作る。"""
    root_path = Path(root)
    
    lines = []
    
    for path in sorted(root_path.rglob('*')):
        if any(part in {".git", "__pycache__",".venv"} for part in path.parts):
            continue
        if path in {
            root_path / "generated" / "report" / "generation_report.md",
            root_path / "generated" / "report" / "write_file_list.txt",
        }:
            continue
        
        relative = path.relative_to(root_path)
        
        indent = "    " * (len(relative.parts) - 1)
        
        if path.is_dir():
            lines.append(f'{indent}{path.name}/')
        else:
            lines.append(f'{indent}{path.name}')
    
    return '\n'.join(lines)


def load_text_files(root: Path) -> tuple[str, list[str]]:
    """指定フォルダ配下のテキスト資料と相対パス一覧を返す。"""
    text_suffixes = {".md", ".robot", ".txt", ".yaml", ".yml", ".json", ".py"}
    sections = []
    relative_paths = []

    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in text_suffixes:
            continue
        if any(part in {".git", "__pycache__", ".venv"} for part in path.relative_to(root).parts):
            continue

        relative_path = path.relative_to(root).as_posix()
        content = path.read_text(encoding="utf-8")
        sections.append(f"## {relative_path}\n\n{content}")
        relative_paths.append(relative_path)

    if not sections:
        raise FileNotFoundError(f"No text documents found under: {root}")

    return "\n\n---\n\n".join(sections), relative_paths


def run_generator(messages, context: RuntimeContext):
    """LLMのtool callを実行し、生成したファイルのパス一覧を返す。"""
    write_file_list = []
    read_counts = Counter()
    MAX_READS_PER_FILE = 2
    MAX_TOOL_ROUNDS = 20

    def process_tool_calls(response):
        """応答内の各tool callを実行し、結果を会話履歴へ戻す。"""
        messages.append(response)
        for tool_call in response.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"]
            tool_call_id = tool_call["id"]

            print(tool_name)
            print(tool_args)

            tool = context.generation_tool_map[tool_name]
            
            if tool_name == "write_file":
                write_path = tool_args["write_file_path"]
                normalized_write_path = Path(write_path).as_posix().removeprefix("./")
                        
            if tool_name == "read_file":
                # 相対パス表記が異なっても同じ実ファイルとして回数を数える。
                read_path = tool_args["read_file_path"]
                path = (context.project_root / read_path).resolve()
                read_counts[path] += 1
            
                if read_counts[path] > MAX_READS_PER_FILE:
                    result = (
                        f"Error: {read_path}は既に複数回読み込んでいます。"
                        "既存の情報を用いて実装に進んでください"
                    )
                    print("warning: read limit exceeded for", read_path)
                else:
                    result = tool.invoke(tool_args)                    
            else:
                result = tool.invoke(tool_args)

            if tool_name == "write_file" and str(result).startswith("Successfully wrote:"):
                # 成功した出力だけを生成物として集計する。
                write_file_list.append(write_path)
                if normalized_write_path == context.generation_decision_path.removeprefix("./"):
                    context.generation_decision_reports.append(tool_args["content"])

            messages.append(
                ToolMessage(
                    content=str(result),
                    tool_call_id=tool_call_id
                )
            )

    def handoff_to_generation():
        """調査上限に達した場合、書き込み専用ツールで実装へ進ませる。"""
        messages.append(HumanMessage(
            content=(
                "調査ラウンドの上限に達しました。これ以上 list_files/read_file を呼ばず、"
                "これまでに得た情報を使って実装してください。"
            )
        ))
        write_file_tool = context.generation_tool_map["write_file"]
        required_writer = context.generate_llm.bind_tools(
            [write_file_tool], tool_choice="required"
        )
        response = required_writer.invoke(messages)
        if not response.tool_calls:
            messages.append(response)
            raise RuntimeError("Generation handoff did not produce a write_file call.")

        process_tool_calls(response)
        writer = context.generate_llm.bind_tools([write_file_tool])
        for _ in range(MAX_TOOL_ROUNDS):
            response = writer.invoke(messages)
            if not response.tool_calls:
                messages.append(response)
                break
            process_tool_calls(response)
        else:
            raise RuntimeError(
                f"Generation stopped after {MAX_TOOL_ROUNDS} write rounds."
            )

    # 調査と実装を交互に許可し、無限のtool callを防ぐ。
    for _ in range(MAX_TOOL_ROUNDS):
        response = context.llm_with_tools.invoke(messages)
        if not response.tool_calls:
            messages.append(response)
            if not write_file_list:
                handoff_to_generation()
            break
        process_tool_calls(response)
    else:
        handoff_to_generation()
    
    return write_file_list


def ensure_generation_decision_report(messages, context: RuntimeContext):
    """生成判断レポートを作成する"""
    if context.generation_decision_reports:
        return []

    messages.append(HumanMessage(
        content=(
            "実装した内容を振り返り、資料に明記された仕様とあなたが推定・仮定した設計判断を区別して、"
            f"{context.generation_decision_path} に簡潔なレポートを作成してください。"
            "判断の理由、影響、実環境で確認が必要な値も記載してください。"
            "内部の逐語的な思考過程ではなく、結論と根拠の要約を記載してください。"
        )
    ))
    write_file_tool = context.generation_tool_map["write_file"]
    writer = context.generate_llm.bind_tools([write_file_tool], tool_choice="required")
    response = writer.invoke(messages)
    messages.append(response)

    written_paths = []
    for tool_call in response.tool_calls:
        if tool_call["name"] != "write_file":
            continue
        tool_args = tool_call["args"]
        result = write_file_tool.invoke(tool_args)
        written_paths.append(tool_args["write_file_path"])
        if Path(tool_args["write_file_path"]).as_posix().removeprefix("./") == context.generation_decision_path.removeprefix("./"):
            context.generation_decision_reports.append(tool_args["content"])
        messages.append(ToolMessage(content=str(result), tool_call_id=tool_call["id"]))

    if not context.generation_decision_reports:
        raise RuntimeError("Generation LLM did not create its implementation-decision report.")
    return written_paths


# 生成物の検証
def run_evaluator(test_messages, context: RuntimeContext):
    """評価を実行し、最終評価テキストを返す。"""
    while True:
        
        response = context.test_llm_with_tools.invoke(test_messages)
        test_messages.append(response)
        
        if not response.tool_calls:
            break
        
        for tool_call in response.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"]
            tool_call_id = tool_call["id"]
            
            print(tool_name)
            print(tool_args)
            
            tool = context.evaluation_tool_map[tool_name]
            result = tool.invoke(tool_args)
            
            test_messages.append(
                ToolMessage(
                    content=str(result),
                    tool_call_id=tool_call_id
                )
            )
    print(response.content)
    return response.content

# 修正の適用
def fix_project(message, eval_result, context: RuntimeContext):
    """評価結果に基づき修正を試みる"""
    message.append(
        create_fix_prompt(eval_result)
    )
    
    return run_generator(message, context)


def main():
    """コード生成、評価・修正の反復、最終レポート出力を実行する。"""
    # モデル・資料の設定は実行時にだけ読み込み、import時には通信しない。
    base_url = 'http://192.168.200.252:18080/v1'
    test_base_url = 'http://192.168.200.252:18081/v1'
    model_name = '/models/qwen3-coder-30b'
    test_model_name = '/models/qwen35-35b-a3b-fp8'

    project_root = Path(__file__).resolve().parents[1]
    platform_root = project_root.parent / "ai-automation-platform"
    current_date = date.today().isoformat()
    documentation_root = project_root / "docs"
    knowledge_root = project_root / "okf_repository"
    procedure_path = (
        project_root
        / "手順書"
        / "手順書_Janog58のシナリオ自動生成テスト用.txt"
    )
    generation_decision_path = platform_root / "src" / "user" / "generated" / "reports" / "実装判断レポート.md"
    report_dir = platform_root / "src" / "user" / "generated" / "reports"

    documentation, _ = load_text_files(documentation_root)
    knowledge, knowledge_paths = load_text_files(knowledge_root)
    procedure_content = procedure_path.read_text(encoding="utf-8").strip()
    if not procedure_content:
        raise ValueError(f"Required procedure is empty: {procedure_path}")
    required_procedure = (
        f"## {procedure_path.relative_to(project_root).as_posix()}\n\n"
        f"{procedure_content}"
    )

    client = httpx.Client(trust_env=False)
    generate_llm = ChatOpenAI(
        model=model_name,
        base_url=base_url,
        api_key="dummy",
        http_client=client,
        temperature=0,
    )
    generate_tools = GenerationTools(project_root)
    generation_tools = generate_tools.get_generation_tools()
    llm_with_tools = generate_llm.bind_tools(generation_tools)
    generation_tool_map = {tool.name: tool for tool in generation_tools}

    test_llm = ChatOpenAI(
        model=test_model_name,
        base_url=test_base_url,
        api_key="dummy",
        http_client=client,
        temperature=0,
    )
    evaluation_tools = generate_tools.get_evaluation_tools()
    test_llm_with_tools = test_llm.bind_tools(evaluation_tools)
    evaluation_tool_map = {tool.name: tool for tool in evaluation_tools}

    context = RuntimeContext(
        documentation=documentation,
        knowledge=knowledge,
        knowledge_paths=knowledge_paths,
        project_root=project_root,
        generation_decision_path=generation_decision_path,
        llm_with_tools=llm_with_tools,
        generate_llm=generate_llm,
        generation_tool_map=generation_tool_map,
        test_llm_with_tools=test_llm_with_tools,
        evaluation_tool_map=evaluation_tool_map,
        generation_decision_reports=[],
    )

    max_retry = 3
    write_file_list = []

    for retry in range(max_retry):
        if retry == 0:
            directory_tree = get_directory_tree(project_root)
            messages = generation_prompt.invoke({
                "okf_documentation": context.documentation,
                "okf_knowledge": context.knowledge,
                "required_procedure": required_procedure,
                "current_date": current_date,
                "directory_tree": directory_tree,
            }).to_messages()

            try:
                write_file_list += run_generator(messages, context)
            except Exception as error:
                print(f"run generator error: {error}")

        # 各評価では、修正後の最新ファイル構成をモデルへ渡す。
        directory_tree = get_directory_tree(project_root)
        write_file_list = list(set(write_file_list))
        test_messages = test_prompt.invoke({
            "okf_documentation": context.documentation,
            "okf_knowledge": context.knowledge,
            "required_procedure": required_procedure,
            "current_date": current_date,
            "directory_tree": directory_tree,
            "write_file_list": write_file_list,
        }).to_messages()

        print("start test")
        eval_result = None
        try:
            eval_result = run_evaluator(test_messages, context)
        except Exception as error:
            print(f"run evaluator error: {error}")

        if eval_result is None:
            continue

        if '"passed": true' in eval_result.lower():
            print("Project passed eval.")
        else:
            print("Project failed eval")
            print("fix...")
            try:
                write_file_list += fix_project(messages, eval_result, context)
            except Exception as error:
                print(f"fix project error: {error}")

    # 最終評価の前に、生成LLM自身の設計判断・仮定を記録する。
    try:
        write_file_list += ensure_generation_decision_report(messages, context)
    except Exception as error:
        print(f"generate decision report error: {error}")

    write_file_list = list(set(write_file_list))
    directory_tree = get_directory_tree(project_root)
    test_messages = test_prompt.invoke({
        "okf_documentation": context.documentation,
        "okf_knowledge": context.knowledge,
        "required_procedure": required_procedure,
        "current_date": current_date,
        "directory_tree": directory_tree,
        "write_file_list": write_file_list,
    }).to_messages()

    print("start test")
    final_eval_result = None
    try:
        final_eval_result = run_evaluator(test_messages, context)
    except Exception as error:
        print(f"run evaluator error: {error}")

    try:
        write_file_list += generate_tools.commit_knowledge_writes()
    except Exception as error:
        print(f"finalize knowledge writes error: {error}")

    write_file_list = list(set(write_file_list))

    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "write_file_list.txt").write_text(
        "\n".join(write_file_list),
        encoding="utf-8",
    )

    # 生成物、設計判断、最終評価を一つの確認用レポートにまとめる。
    report_sections = [
        "# コード生成レポート",
        "## 生成ファイル",
        "\n".join(f"- {path}" for path in write_file_list) if write_file_list else "生成ファイルはありません。",
        "## 生成時に読み込んだナレッジ",
        "以下は生成時にLLMへ提供したナレッジファイルです。実際に設計判断の根拠として参照したファイルと内容は、生成LLMの設計判断レポートに記載しています。\n\n"
        + ("\n".join(
            f"- okf_repository/{path}"
            for path in context.knowledge_paths
        ) if context.knowledge_paths else "ナレッジファイルはありません。"),
        "## 生成LLMの設計判断・推定内容",
        context.generation_decision_reports[-1] if context.generation_decision_reports else "生成LLMの実装判断レポートを取得できませんでした。",
        "## 評価LLMによる仕様の不足情報・実装評価",
        final_eval_result if final_eval_result else "評価LLMの最終応答を取得できませんでした。",
    ]
    (report_dir / "generation_report.md").write_text(
        "\n\n".join(report_sections),
        encoding="utf-8",
    )
    print("Generation report: ai-automation-platform/src/user/generated/reports/generation_report.md")


if __name__ == "__main__":
    main()